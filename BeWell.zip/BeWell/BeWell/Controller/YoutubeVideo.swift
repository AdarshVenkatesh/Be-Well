//
//  YoutubeVideo.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class YouTubeVideo: UITableViewController {
    let Youtube_API = "AIzaSyApm2pWydS6oZ0ef6snVLFBayClL-H58M8"
    
    var result: VideoResults?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Play List of Videos"
        
        
        view.backgroundColor = UIColor.black
        
        getVideoList {
            self.tableView.reloadData()
        }
        
        tableView.register(ListCell7.self, forCellReuseIdentifier: "videocellid")
    }
    
    // JSON decoding after Fetching data from Youtube data api
    func getVideoList(completed: @escaping () -> () ) {
        
        let urlString = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&order=date&maxResults=20&playlistId=PLJRbJuI_csVAMq2VPr96h6TL4Y98rfznM&key=AIzaSyApm2pWydS6oZ0ef6snVLFBayClL-H58M8"

        let url = URL(string: urlString)
        
        URLSession.shared.dataTask(with: url!){ (data, response, err) in
            if err == nil {
                // check downloaded JSON data
                guard let jsondata = data else { return }
                
                print(jsondata)
                do {
                    self.result = try JSONDecoder().decode(VideoResults.self, from: jsondata)
                    
                    DispatchQueue.main.async {
                        completed()
                    }
                }catch {
                    print("JSON Downloading Error!")
                }
            }
            }.resume()
    }
    
    // table view delegates
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let number = result?.items.count {
            return number
        }
        return 0
    }
    
    func showDetailOfVideo(video: VideoItem){
        let detailController = VideoDetailViewController()
        detailController.video = video
        present(detailController, animated: true, completion: nil)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let video = result?.items[indexPath.row] {
            self.showDetailOfVideo(video: video)
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let video = result?.items[indexPath.row] {
            let cell = tableView.dequeueReusableCell(withIdentifier: "videocellid", for: indexPath) as! ListCell7
            
            if let urlstring = video.snippet?.thumbnails?.medium?.url {
                cell.thumnailImageView.downloadimageUsingcacheWithLink(urlstring)
            }
            if let title = video.snippet?.title {
                cell.label.text = title
            }
        }
        return UITableViewCell()
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250
    }
}


// TableView Cell
class ListCell7: UITableViewCell {
    
    let thumnailImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.cornerRadius = 10
        imageView.layer.masksToBounds = true
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    let label: UILabel = {
        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.font = UIFont.systemFont(ofSize: 18)
        lbl.backgroundColor = UIColor.orange
        lbl.textColor = .white
        return lbl
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        addSubview(thumnailImageView)
        
        // anchor to the superview (cell view)
        thumnailImageView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        thumnailImageView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
        thumnailImageView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        thumnailImageView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        
        thumnailImageView.addSubview(label)
        label.leftAnchor.constraint(equalTo: thumnailImageView.leftAnchor).isActive = true
        label.rightAnchor.constraint(equalTo: thumnailImageView.rightAnchor).isActive = true
        label.bottomAnchor.constraint(equalTo: thumnailImageView.bottomAnchor, constant: -10).isActive = true
        label.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
