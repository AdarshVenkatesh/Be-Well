//
//  VideoDetailViewController.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import AVFoundation

class VideoDetailViewController: UIViewController, UIWebViewDelegate {
    var video: VideoItem?
    
    let navBar:UINavigationBar = {
        let nv = UINavigationBar()
        return nv
    }()
    
    let webView:UIWebView = {
        let wv = UIWebView()
        wv.backgroundColor = .yellow
        wv.translatesAutoresizingMaskIntoConstraints = false
        return wv
    }()
    
    
    // for scroll view
    let labelOne: UILabel = {
        let label = UILabel()
        label.text = "Scroll Top"
        label.backgroundColor = .red
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let labelTwo: UILabel = {
        let label = UILabel()
        label.text = "Scroll Bottom"
        label.backgroundColor = .green
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    let scrollView: UIScrollView = {
        let v = UIScrollView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .cyan
        return v
    }()
    
    // container view for AV Player
    let playerContainer: UIView = {
        let view = UIView()
        view.backgroundColor = .blue
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = 16
        view.layer.masksToBounds = true
        return view
    }()
    
    var playerLayer: AVPlayerLayer?
    var player: AVPlayer?
    
    var videoImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.layer.cornerRadius = 16
        imageView.layer.masksToBounds = true
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        setNavigationBar()
        
        setupViews()
        
        getVideoUsingLoadRequest(videoCode: (video?.snippet?.resourceId?.videoId)!)
    }
    
    func setNavigationBar() {
        let navItem = UINavigationItem()
        navItem.title = video?.snippet?.title
        let doneItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: nil, action: #selector(done))

        navItem.rightBarButtonItem = doneItem
        navItem.rightBarButtonItem?.tintColor = UIColor.white
        navBar.setItems([navItem], animated: false)
        
        view.addSubview(navBar)
        
        navBar.translatesAutoresizingMaskIntoConstraints = false
        navBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        navBar.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor).isActive = true
        navBar.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor).isActive = true
        navBar.heightAnchor.constraint(equalToConstant: 44).isActive = true
    }
    
    @objc func done() {
        dismiss(animated: true, completion: nil)
    }
    
    
    func setupViews() {
        webView.delegate = self
        
        view.addSubview(webView)
        webView.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor).isActive = true
        
       // webView.topAnchor.constraint(equalTo: navBar.bottomAnchor, constant: 5).isActive = true
        webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        
        webView.heightAnchor.constraint(equalToConstant: 180).isActive = true
        
        webView.allowsInlineMediaPlayback = true
        
      
    }
    
    // Web View Load Request! can be done with delegate webViewshouldStartLoadWithRequest
    func getVideoUsingLoadRequest(videoCode: String) {
        let url = URL(string: "https://www.youtube.com/embed/\(videoCode)?&playsinline=1")
        
        webView.loadRequest(URLRequest(url: url!))
        
    }
    
    // finishPlayigHandler for AVPlayer
    @objc func playerDidFinishPlaying(note: NSNotification){
        print(note)
    }
    
    // Cannot request new connection while previous one is in the process
    // MARK -- WebView Delegates
    
    // when loading finishes, make ready to start loading video for AVPlayer
    func webViewDidFinishLoad(_ webView: UIWebView) {
        let urlString =  "https://www.rmp-streaming.com/media/bbb-360p.mp4"
        if let url = URL(string: urlString) {
            let asset = AVURLAsset(url: url)
            let playerItem = AVPlayerItem(asset: asset)
            
            // add notification when Player finishes playing
            NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying), name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: playerItem)
            
            player = AVPlayer(playerItem: playerItem)
            //player = AVPlayer(url: url)
            
            
            playerLayer = AVPlayerLayer(player: player)
            playerLayer?.frame = playerContainer.bounds
            playerContainer.layer.addSublayer(playerLayer!)
            
            player?.play()
        }
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        // will be useful to check
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        // useful to check the reason of failing
    }
}

