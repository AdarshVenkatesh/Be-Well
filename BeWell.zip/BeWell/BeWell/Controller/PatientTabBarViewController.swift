//
//  PatientViewController.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/13/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PatientTabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.barTintColor = UIColor(red: 38/255,green:196/255, blue: 133/255, alpha:1)
        
          navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(handlelogout))
        setUpTabBar()
        
    }
    
    func setUpTabBar(){
        

        let scanController = createTabBar(vc: ScanViewController(), selected: UIImage(named: "starselected")!, nonselected: UIImage(named: "starunselected")!)
         let ordersController = createTabBar(vc: PatientOrdersTableViewController(), selected: UIImage(named: "starselected")!, nonselected: UIImage(named: "starunselected")!)
         let profController = createTabBar(vc: ProfileViewController(), selected: UIImage(named: "starselected")!, nonselected: UIImage(named: "starunselected")!)
        
        
        
        viewControllers = [scanController,ordersController,profController]
        
        guard let items = tabBar.items else {return }
        
        for item in items {
            item.imageInsets = UIEdgeInsetsMake(4,0, -4, 0)
        }
    }
    
    
    @objc func handlelogout(){
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        
        let login = LoginViewController()
        let navCotroller = UINavigationController(rootViewController: login)
        present(navCotroller, animated: true, completion: nil)
    }

}
extension UITabBarController{
    
    func createTabBar(vc:UIViewController,selected:UIImage,nonselected:UIImage)-> UINavigationController{
        let viewController = vc
        let navController = UINavigationController(rootViewController: viewController)
        navController.tabBarItem.image = nonselected
        navController.tabBarItem.selectedImage = selected
        return navController
    }
}
