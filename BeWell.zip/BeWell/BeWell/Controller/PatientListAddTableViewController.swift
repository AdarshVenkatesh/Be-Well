//
//  PatientListAddTableViewController.swift
//  BeWell
//
//  Created by toppy on 4/15/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase
class PatientListAddTableViewController: UITableViewController,UINavigationControllerDelegate  {
    var ref: DatabaseReference!
    var authref: Auth!
    var patientslist = [PatientModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref  = Database.database().reference()
        authref = Auth.auth()
        downloadJson()
        navigationItem.title="Add Patients"
        tableView.register(PatientListAddCell.self, forCellReuseIdentifier: "addcellid")
    }

    
    func downloadJson(){
        let patientsref = ref.child("patients")

        // Event Listener!!!!
        patientsref.observe(.childAdded, with: { (snapshot) in
            
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                
                let patient = PatientModel(dictionary: dictionary)
                self.patientslist.append(patient)
                 DispatchQueue.main.async {
                self.tableView.reloadData()
                }
            }
            
        }, withCancel: nil)
    }
 

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return patientslist.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let patient = patientslist[indexPath.row] as? PatientModel{
            let cell = tableView.dequeueReusableCell(withIdentifier: "addcellid", for: indexPath) as! PatientListAddCell
            
            let posterlink = patient.imageurl
            if(posterlink != nil){
                cell.iconImageView.downloadimageUsingcacheWithLink(posterlink!)
            }

            cell.addIcon.image = UIImage(named: "add")
            cell.textLabel?.text = patient.name
            cell.detailTextLabel?.textColor = .black
            cell.detailTextLabel?.text = patient.age
            cell.tag = indexPath.row
            return cell
            
        }
        return UITableViewCell()
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let patient = patientslist[indexPath.row] as? PatientModel{
            showToast(message:  "\(patient.name!) is Added")
            
            guard let uid = Auth.auth().currentUser?.uid else{
                return
            }
            ref.child("doctors").child(uid).child(patient.uid!).setValue(["email": patient.email,"name": patient.name, "age": patient.age,"uid":patient.uid,"imageurl":patient.imageurl])
        }
    }

}
