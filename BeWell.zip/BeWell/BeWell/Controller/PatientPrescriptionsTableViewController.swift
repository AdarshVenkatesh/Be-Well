//
//  PatientPrescriptionsTableViewController.swift
//  BeWell
//
//  Created by toppy on 5/4/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PatientPrescriptionsTableViewController: UITableViewController {
    var ref: DatabaseReference!
    var authref: Auth!
    var prescriptions = [eachPrescription]()
    var patient : PatientModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ref  = Database.database().reference()
        authref = Auth.auth()
        view.backgroundColor = UIColor.white
        downloadJson()
        tableView.register(ListCell1.self, forCellReuseIdentifier: "prescriptioncellid")
        
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:  #selector(downloadJson), for: UIControlEvents.valueChanged)
        self.refreshControl = refreshControl
    }


    @objc func downloadJson(){
        prescriptions.removeAll()
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
        let prescripref = ref.child("prescriptions").child(uid)
        
        // Event Listener!!!!
        prescripref.observe(.childAdded, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let prescrip = eachPrescription(dictionary: dictionary)
                self.prescriptions.append(prescrip)
                print(self.prescriptions.count)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
            
        }, withCancel: nil)
        refreshControl?.endRefreshing()
    }
    
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return prescriptions.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let prescription = prescriptions[indexPath.row] as? eachPrescription{
            let cell = tableView.dequeueReusableCell(withIdentifier: "prescriptioncellid", for: indexPath) as! ListCell1
            
            cell.time.text = "At: \(prescription.time!)"
            
            cell.textLabel?.text = prescription.disease

            cell.detailTextLabel?.textColor = .black
            cell.detailTextLabel?.text = prescription.pill
            return cell
            
        }
        return UITableViewCell()
    }

}
