//
//  PlaceOrderViewController.swift
//  BeWell
//
//  Created by toppy on 4/17/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PlaceOrderViewController: UIViewController {
    var url: String?
    var pharmacist: PharmacistModel?
    var userIs: UserModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        guard let uid = Auth.auth().currentUser?.uid else {
            //for some reason uid = nil
            return
        }
        
        // fetch User info! Set up Navigation Bar!
        Database.database().reference().child("users").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let user = UserModel(dictionary: dictionary)
               self.userIs = user
            }
            
        }, withCancel: nil)

        
         setupviews()
    }
    
    
    let placeLabel : UILabel = {
        let label = UILabel()
        label.text = "Click to place Order"
        label.textAlignment =  NSTextAlignment.justified
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 25)
        label.isUserInteractionEnabled = false
        return label
    }()
    
    


    let place : UIButton = {
        let place = UIButton()
        place.layer.cornerRadius = 10
        place.clipsToBounds = true
        place.setImage(UIImage(named: "place"), for: .normal)
        place.translatesAutoresizingMaskIntoConstraints = false
        place.addTarget(self, action: #selector(handlePlace), for: .touchUpInside)
        return place
    }()
    
    
    @objc func handlePlace(){
        showToast(message: "Order Placed")
        
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
        
        let ct = Int64(NSDate().timeIntervalSince1970 * 1000)
        print(ct)
        print(userIs?.name); Database.database().reference().child("pharmacists").child((pharmacist?.uid)!).child(String(ct)).setValue(["orderId":String(ct),"orderDetail":url,"patientName":userIs?.name,"patientImageurl":userIs?.imageurl,"patientuid":uid])
        
        Database.database().reference().child("patients").child(uid).child(String(ct)).setValue(["orderId":String(ct),"orderDetail":url,"pharmacistName":pharmacist?.name,"pharmacistImageurl":pharmacist?.imageurl])
    }
    
    
    
    func setupviews(){
        view.addSubview(place)
        place.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        place.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        place.widthAnchor.constraint(equalToConstant: 100).isActive = true
        place.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        
        view.addSubview(placeLabel)
        placeLabel.bottomAnchor.constraint(equalTo: place.topAnchor, constant: -30).isActive = true
        placeLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        placeLabel.widthAnchor.constraint(equalToConstant: 250).isActive = true
        placeLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true

    }
    

}
