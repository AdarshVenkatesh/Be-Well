//
//  PharmasListTableViewController.swift
//  BeWell
//
//  Created by toppy on 4/17/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PharmasListTableViewController: UITableViewController ,UINavigationControllerDelegate  {

    var ref: DatabaseReference!
    var authref: Auth!
    var pharmacistslist = [PharmacistModel]()
    var url : String?
    override func viewDidLoad() {
        super.viewDidLoad()

        ref  = Database.database().reference()
        authref = Auth.auth()
     //   checkIfUserIsLoggedIn()
        setupNavBar()
        downloadJson()
        tableView.register(PharmaListCell.self, forCellReuseIdentifier: "pharmacellid")
    }

    func downloadJson(){
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
        let pharmaref = ref.child("pharmacists")
        
        // Event Listener!!!!
        pharmaref.observe(.childAdded, with: { (snapshot) in
            
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                
                let pharmacist = PharmacistModel(dictionary: dictionary)
                self.pharmacistslist.append(pharmacist)
                print(self.pharmacistslist.count)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
            
        }, withCancel: nil)
    }

    
    func setupNavBar(){
        navigationItem.title = "Pharmacists"
     //   navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(handlelogout))
        //  navigationController?.navigationBar.isTranslucent = false
      
    }
    
    @objc func handlelogout(){
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        
        let login = LoginViewController()
        let navCotroller = UINavigationController(rootViewController: login)
        present(navCotroller, animated: true, completion: nil)
    }
    
    
    func checkIfUserIsLoggedIn() {
        // if not sign in, display login screen!!!
        if Auth.auth().currentUser?.uid == nil {
        } else {
            fetchUserAndSetupNavBarTitle()
        }
    }
    
    
    func fetchUserAndSetupNavBarTitle() {
        guard let uid = Auth.auth().currentUser?.uid else {
            //for some reason uid = nil
            return
        }
        
        // fetch User info! Set up Navigation Bar!
        Database.database().reference().child("users").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let user = UserModel(dictionary: dictionary)
                self.setupNavBarWithUser(user: user)
            }
            
        }, withCancel: nil)
    }
    
    
    func setupNavBarWithUser(user: UserModel) {
        
        //  let titleView = TitleView(frame: CGRect(x: 0, y: 0, width: 150, height: 40))
        let titleView = TitleView(frame: CGRect(x: 0, y:0, width:150,height: 40))
        self.navigationItem.titleView = titleView
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        
        titleView.isUserInteractionEnabled = true
        
        titleView.addGestureRecognizer(tap)
        
        if let profileImageUrl = user.imageurl {
            titleView.profileImageView.downloadimageUsingcacheWithLink(profileImageUrl)
            
        }
        titleView.nameLabel.text = user.name
        
        // fetchLists()
    }
    
    
    // When NavBar TitleView is Tapped!!! Edit User Profile!!!
    @objc private func handleTap(){
        let profileController = ProfileViewController()
        navigationController?.pushViewController(profileController, animated: true)
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
  
        if let pharmacist = pharmacistslist[indexPath.row] as? PharmacistModel{
            let cell = tableView.dequeueReusableCell(withIdentifier: "pharmacellid", for: indexPath) as! PharmaListCell
            let posterlink = pharmacist.imageurl
            if(posterlink != nil){
                cell.iconImageView.downloadimageUsingcacheWithLink(posterlink!)
            }
            
            cell.textLabel?.text = pharmacist.name
            cell.detailTextLabel?.textColor = .black
            cell.detailTextLabel?.text = pharmacist.email
            return cell
            
        }
        return UITableViewCell()
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return pharmacistslist.count
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let pharmacist = pharmacistslist[indexPath.row] as? PharmacistModel{
            let place = PlaceOrderViewController()
            place.url = url
            place.pharmacist = pharmacist
            navigationController?.pushViewController(place, animated: true)
        }
    }




}
