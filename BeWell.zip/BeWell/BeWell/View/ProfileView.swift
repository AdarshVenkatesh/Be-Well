//
//  ProfileView.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/13/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class ProfileView: UIView {
    var userModel: UserModel?{
        
        didSet{
            
            if let name1 = userModel?.name {
                print(name1)
                name.text = name1
                
            }
            
            if let email1 = userModel?.email {
                
                email.text = email1
            }
            
            if let age1 = userModel?.age {
                age.text = age1
            }
            
            
            if let occupation1 = userModel?.occupation {
                occupation.text = occupation1
            }
            
        }
    }
    
    let namelabel: UILabel = {
        let nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false;
        nameLabel.text = "Name:"
        nameLabel.font = nameLabel.font.withSize(30)
        return nameLabel
    }()
    
    
    let name: UILabel = {
        let name = UILabel()
        name.translatesAutoresizingMaskIntoConstraints = false
        name.font = name.font.withSize(30)
        return name
    }()
    
    let emaillabel: UILabel = {
        let emaillabel = UILabel()
        emaillabel.translatesAutoresizingMaskIntoConstraints = false;
        emaillabel.text = "Email:"
        emaillabel.font = emaillabel.font.withSize(30)
        return emaillabel
    }()
    
    
    let email: UILabel = {
        let email = UILabel()
        email.translatesAutoresizingMaskIntoConstraints = false
        email.font = email.font.withSize(30)
        return email
    }()
    
    let agelabel: UILabel = {
        let agelabel = UILabel()
        agelabel.translatesAutoresizingMaskIntoConstraints = false;
        agelabel.text = "Age:"
        agelabel.font = agelabel.font.withSize(30)
        return agelabel
    }()
    
    
    let age: UILabel = {
        let age = UILabel()
        age.translatesAutoresizingMaskIntoConstraints = false
        age.font = age.font.withSize(30)
        return age
    }()
    
    
    let occupationlabel: UILabel = {
        let countrylabel = UILabel()
        countrylabel.translatesAutoresizingMaskIntoConstraints = false;
        countrylabel.text = "Occupation:"
        countrylabel.font = countrylabel.font.withSize(30)
        return countrylabel
    }()
    
    
    let occupation: UILabel = {
        let country = UILabel()
        country.translatesAutoresizingMaskIntoConstraints = false
        country.font = country.font.withSize(30)
        return country
    }()
    
    
    
    func setupviews(){
        
        let stackview : UIStackView = {
            let stackview = UIStackView()
            stackview.axis  = UILayoutConstraintAxis.horizontal
            stackview.distribution  = .fill
            stackview.alignment = UIStackViewAlignment.fill
            stackview.spacing   = 1
            stackview.translatesAutoresizingMaskIntoConstraints = false
            stackview.heightAnchor.constraint(equalToConstant: 10)
            stackview.addArrangedSubview(namelabel)
            stackview.addArrangedSubview(name)
            return stackview
        }()
        addSubview(stackview)
        addConstraintsWithFormat("H:|[v0]|", views: stackview)
        addConstraintsWithFormat("H:|-10-[v0]-10-[v1(200)]|", views: namelabel,name)
        
        let stackview1 : UIStackView = {
            let stackview = UIStackView()
            stackview.axis  = UILayoutConstraintAxis.horizontal
            stackview.distribution  = .fill
            stackview.alignment = UIStackViewAlignment.fill
            stackview.spacing   = 1
            stackview.translatesAutoresizingMaskIntoConstraints = false
            stackview.heightAnchor.constraint(equalToConstant: 10)
            stackview.addArrangedSubview(emaillabel)
            stackview.addArrangedSubview(email)
            return stackview
        }()
        addSubview(stackview1)
        addConstraintsWithFormat("H:|[v0]|", views: stackview1)
        addConstraintsWithFormat("H:|-10-[v0]-10-[v1(200)]|", views: emaillabel,email)
  
        let stackview2 : UIStackView = {
            let stackview = UIStackView()
            stackview.axis  = UILayoutConstraintAxis.horizontal
            stackview.distribution  = .fill
            stackview.alignment = UIStackViewAlignment.fill
            stackview.spacing   = 1
            stackview.translatesAutoresizingMaskIntoConstraints = false
            stackview.heightAnchor.constraint(equalToConstant: 10)
            
            stackview.addArrangedSubview(agelabel)
            stackview.addArrangedSubview(age)
            
            return stackview
        }()
        
        addSubview(stackview2)
        addConstraintsWithFormat("H:|[v0]|", views: stackview2)
        addConstraintsWithFormat("H:|-10-[v0]-10-[v1(200)]|", views: agelabel,age)
        
        let stackview3 : UIStackView = {
            let stackview = UIStackView()
            stackview.axis  = UILayoutConstraintAxis.horizontal
            stackview.distribution  = .fill
            stackview.alignment = UIStackViewAlignment.fill
            stackview.spacing   = 1
            stackview.translatesAutoresizingMaskIntoConstraints = false
            stackview.heightAnchor.constraint(equalToConstant: 10)
            
            stackview.addArrangedSubview(occupationlabel)
            stackview.addArrangedSubview(occupation)
            
            return stackview
        }()
        
        addSubview(stackview3)
      //  addConstraintsWithFormat("H:|[v0]|", views: stackview3)
        addConstraintsWithFormat("H:|-10-[v0]-10-[v1(200)]|", views: occupationlabel,occupation)
        
        addConstraintsWithFormat("H:|[v0]|", views: stackview3)
        addConstraintsWithFormat("V:|-10-[v0]-15-[v1]-15-[v2]-15-[v3]-10-|", views: stackview,stackview1,stackview2,stackview3)
  
        
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}



extension UIView {
    func addConstraintsWithFormat(_ format: String, views: UIView...) {
        var viewsDictionary = [String: UIView]()
        for (index, view) in views.enumerated() {
            let key = "v\(index)"
            view.translatesAutoresizingMaskIntoConstraints = false
            viewsDictionary[key] = view
        }
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: format, options: NSLayoutFormatOptions(), metrics: nil, views: viewsDictionary))
    }
}
