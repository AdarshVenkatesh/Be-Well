//
//  FetchPlace.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import CoreLocation

class FetchPlace{
    let name: String
    let placeid: String
    let address: String
    let coordinate: CLLocationCoordinate2D
    let placeType: String
    let photoref: String
    let rating: Double
    
    init(name: String, placeid: String, address: String, coordinate: CLLocationCoordinate2D, placeType: String, photoref: String, rating: Double) {
        self.name = name
        self.address = address
        self.coordinate = coordinate
        self.placeid = placeid
        self.placeType = placeType
        self.photoref = photoref
        self.rating = rating
    }
}
