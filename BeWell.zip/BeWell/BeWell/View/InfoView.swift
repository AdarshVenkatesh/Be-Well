//
//  InfoView.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class InfoView: UIView {
    let nameLbl: UILabel = {
        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        return lbl
    }()
    
    let imageView: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.translatesAutoresizingMaskIntoConstraints = false
        return iv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(nameLbl)
        nameLbl.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        nameLbl.topAnchor.constraint(equalTo: self.topAnchor, constant: 5).isActive = true
        nameLbl.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        addSubview(imageView)
        imageView.topAnchor.constraint(equalTo: nameLbl.bottomAnchor, constant: 10).isActive = true
        imageView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        imageView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
