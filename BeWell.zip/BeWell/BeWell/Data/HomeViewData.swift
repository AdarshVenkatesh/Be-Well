//
//  HomeViewData.swift
//  BeWell
//
//  Created by toppy on 5/2/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import Foundation

var HomeData: [HomeModel] = [
    HomeModel(imageName: "orders1" , name:"Orders",descrip:"Check the orders status"),
    HomeModel(imageName: "qrscan-2" , name:"Scan",descrip:"Scan and Order here"),
    HomeModel(imageName: "prescriptions" , name:"Prescriptions",descrip:"Check your prescriptions"),
    HomeModel(imageName: "maps-1" , name:"Maps",descrip:"Search for places"),
    HomeModel(imageName: "youtube" , name:"Youtube",descrip:"Checkout health tips"),
    HomeModel(imageName: "profile" , name:"Profile",descrip:""),
    HomeModel(imageName: "share-2" , name:"Share",descrip:"Share this App"),
     HomeModel(imageName: "logout" , name:"Logout",descrip:""),
]
