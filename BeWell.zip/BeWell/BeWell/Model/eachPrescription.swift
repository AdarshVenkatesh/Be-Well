//
//  eachPrescription.swift
//  BeWell
//
//  Created by toppy on 4/15/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class eachPrescription: NSObject {
    var disease: String?
    var pill: String?
    var time: String?
    var timestamp: String?
    
    
    init(dictionary: [String: AnyObject]) {
        self.disease = dictionary["disease"] as? String
        self.pill = dictionary["pill"] as? String
        self.time = dictionary["time"] as? String
        self.timestamp = dictionary["timestamp"] as? String
    }
}
