//
//  MapSearchViewController.swift
//  BeWell
//
//  Created by toppy on 5/1/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces

class MapSearchViewController: UIViewController, UISearchBarDelegate,LocateOnTheMap{

    var googleMapsview: GMSMapView!
    var searchResultsController: SearchResultsController!
    var resultsArray = [String]()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        let menuLeftButton = UIBarButtonItem(image: UIImage(named: "searchs")?.withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(handleSearch))
        navigationItem.rightBarButtonItem = menuLeftButton
        navigationItem.rightBarButtonItem?.tintColor = UIColor.white
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(handleDone))
          navigationItem.leftBarButtonItem?.tintColor = UIColor.white
    }
    
     @objc func handleDone(){
        let profController = PatientHomeViewController()
        let navCotroller = UINavigationController(rootViewController: profController)
        self.present(navCotroller, animated: true, completion: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.googleMapsview = GMSMapView(frame: view.bounds)
        self.view.addSubview(googleMapsview)
        
        searchResultsController = SearchResultsController()
        searchResultsController.delegate = self

    }

    @objc func handleSearch(){
        let searchController = UISearchController(searchResultsController: searchResultsController)
        searchController.searchBar.delegate = self
        self.present(searchController, animated: true, completion: nil)
    }

    func locateWithLongitude(_ lon: Double, andLatitude lat: Double, andTitle title: String) {
        DispatchQueue.main.async {
            let position = CLLocationCoordinate2DMake(lat, lon)
            let marker = GMSMarker(position: position)
            
            let camera = GMSCameraPosition.camera(withLatitude: lat, longitude: lon, zoom: 10)
            self.googleMapsview.camera = camera
            
            marker.title = "Address : \(title)"
            marker.map = self.googleMapsview
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        DispatchQueue.main.async {
        let placeClient = GMSPlacesClient()
        placeClient.autocompleteQuery(searchText, bounds: nil, filter: nil){
            (results,error)-> Void in
            self.resultsArray.removeAll()
            if results == nil {
                return
            }
            for result in results! {
                if let result = result as? GMSAutocompletePrediction {
                    self.resultsArray.append(result.attributedFullText.string)
                }
            }
                self.searchResultsController.reloadDataWithArray(self.resultsArray)
            }
            
        }
    }
}
