//
//  OrderModel.swift
//  BeWell
//
//  Created by toppy on 4/17/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class OrderModel: NSObject {

    var orderId: String?
    var orderDetail: String?
    var patientName: String?
    var patientImageurl: String?
    var pharmacistImageurl: String?
    var pharmacistName: String?
    var patientuid:String?
    var notified:String?
    
    init(dictionary: [String: AnyObject]) {
        self.orderId = dictionary["orderId"] as? String
        self.orderDetail = dictionary["orderDetail"] as? String
        self.patientName = dictionary["patientName"] as? String
        self.patientImageurl = dictionary["patientImageurl"] as? String
       self.pharmacistImageurl = dictionary["pharmacistImageurl"] as? String
        self.pharmacistName = dictionary["pharmacistName"] as? String
        self.patientuid = dictionary["patientuid"] as? String
        self.notified = dictionary["notified"] as? String
    }
    
}
