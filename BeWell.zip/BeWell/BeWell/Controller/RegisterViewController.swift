//
//  RegisterViewController.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/12/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class RegisterViewController: UIViewController ,UITextFieldDelegate{

    var ref: DatabaseReference!
    var authref: Auth!
    var chckbox1: Bool!
    var chckbox2: Bool!
    var chckbox3: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        ref  = Database.database().reference()
        authref = Auth.auth()
        
        
        view.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(handleBack))
        navigationItem.leftBarButtonItem?.tintColor = .white
         view.addSubview(inputContainerView)
        view.addSubview(registerButton)
        view.addSubview(checkbox1)
        view.addSubview(doctor)
        view.addSubview(checkbox2)
        view.addSubview(patient)
        view.addSubview(checkbox3)
        view.addSubview(pharmacist)
        
        setConstraintsContainerView()
        setConstraintsRegisterButton()
        setConstraintsCheckbox1()
        setConstraintsDoctor()
        setConstraintsCheckbox2()
        setConstraintsPatient()
        setConstraintsCheckbox3()
        setConstraintsPharmacist()
        
        NameTextFiled.delegate = self
        emailTextFiled.delegate = self
        passwordTextFiled.delegate = self
        ageTextFiled.delegate = self
        
        chckbox1 = false
        chckbox2 = false
        chckbox3 = false
        
    }
    @objc func handleBack()
    {
        dismiss(animated: true, completion: nil)
    }

    
    
    let inputContainerView: UIView =
    {
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = UIColor.white
        containerView.layer.cornerRadius = 5
        containerView.layer.masksToBounds = true
        return containerView
    }()
    
    
    let NameTextFiled: UITextField = {
        let email = UITextField()
        email.translatesAutoresizingMaskIntoConstraints = false
        email.placeholder = "Name"
        email.returnKeyType = UIReturnKeyType.done
        return email
    }()
    
    let seperatorView: UIView = {
        let line = UIView()
        line.translatesAutoresizingMaskIntoConstraints = false
        line.backgroundColor = UIColor.black
        return line
    }()
    
    let emailTextFiled: UITextField = {
        let email = UITextField()
        email.translatesAutoresizingMaskIntoConstraints = false
        email.placeholder = "Email"
        email.returnKeyType = UIReturnKeyType.done
        return email
    }()
    let seperatorView2: UIView = {
        let line = UIView()
        line.translatesAutoresizingMaskIntoConstraints = false
        line.backgroundColor = UIColor.black
        return line
    }()
    
    let seperatorView3: UIView = {
        let line = UIView()
        line.translatesAutoresizingMaskIntoConstraints = false
        line.backgroundColor = UIColor.black
        
        return line
    }()
    
    let passwordTextFiled: UITextField = {
        let password = UITextField()
        password.translatesAutoresizingMaskIntoConstraints = false
        password.placeholder = "Password"
        password.isSecureTextEntry = true
        password.returnKeyType = UIReturnKeyType.done
        return password
    }()
    
    let ageTextFiled: UITextField = {
        let age = UITextField()
        age.translatesAutoresizingMaskIntoConstraints = false
        age.placeholder = "Age"
        age.keyboardType = UIKeyboardType.numberPad
        age.returnKeyType = UIReturnKeyType.done
        return age
    }()
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        self.ageTextFiled.resignFirstResponder()
        passwordTextFiled.resignFirstResponder()
        emailTextFiled.resignFirstResponder()
        NameTextFiled.resignFirstResponder()
        return true
    }
    
    
    let checkbox1: UIButton = {
        let chckbox = UIButton()
        let image = UIImage(named: "checkboxempty") as UIImage?
        chckbox.translatesAutoresizingMaskIntoConstraints = false
        chckbox.setBackgroundImage(image, for: .normal)
        chckbox.addTarget(self, action: #selector(handleCheckbox1), for: .touchUpInside)
        return chckbox
    }()
    
    @objc func handleCheckbox1(){
        chckbox1 = true
        chckbox2 = false
        chckbox3 = false
        let image1 = UIImage(named: "checkboxchecked") as UIImage?
        let image2 = UIImage(named: "checkboxempty") as UIImage?
        let image3 = UIImage(named: "checkboxempty") as UIImage?
        checkbox1.setBackgroundImage(image1, for: .normal)
        checkbox2.setBackgroundImage(image2, for: .normal)
        checkbox3.setBackgroundImage(image3, for: .normal)
    }
    
    let doctor: UITextField = {
        let doctor = UITextField()
        doctor.translatesAutoresizingMaskIntoConstraints = false
        doctor.text = "Doctor"
        doctor.isUserInteractionEnabled = false
        doctor.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        doctor.textColor = UIColor.white
        return doctor
    }()
    
    let checkbox2: UIButton = {
        let chckbox = UIButton()
        let image = UIImage(named: "checkboxempty") as UIImage?
        chckbox.translatesAutoresizingMaskIntoConstraints = false
        chckbox.setBackgroundImage(image, for: .normal)
        chckbox.addTarget(self, action: #selector(handleCheckbox2), for: .touchUpInside)
        return chckbox
    }()
    
    @objc func handleCheckbox2(){
        chckbox1 = false
        chckbox2 = true
        chckbox3 = false

        let image1 = UIImage(named: "checkboxempty") as UIImage?
        let image2 = UIImage(named: "checkboxchecked") as UIImage?
        let image3 = UIImage(named: "checkboxempty") as UIImage?
        checkbox1.setBackgroundImage(image1, for: .normal)
        checkbox2.setBackgroundImage(image2, for: .normal)
        checkbox3.setBackgroundImage(image3, for: .normal)
    }
    
    let patient: UITextField = {
        let patient = UITextField()
        patient.translatesAutoresizingMaskIntoConstraints = false
        patient.text = "Patient"
        patient.isUserInteractionEnabled = false
        patient.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        patient.textColor = UIColor.white
        return patient
    }()
    
    let checkbox3: UIButton = {
        let chckbox = UIButton()
        let image = UIImage(named: "checkboxempty") as UIImage?
        chckbox.translatesAutoresizingMaskIntoConstraints = false
        chckbox.setBackgroundImage(image, for: .normal)
         chckbox.addTarget(self, action: #selector(handleCheckbox3), for: .touchUpInside)
        return chckbox
    }()
    
    
    @objc func handleCheckbox3(){
        chckbox1 = false
        chckbox2 = false
        chckbox3 = true

        let image1 = UIImage(named: "checkboxempty") as UIImage?
        let image2 = UIImage(named: "checkboxempty") as UIImage?
        let image3 = UIImage(named: "checkboxchecked") as UIImage?
        checkbox1.setBackgroundImage(image1, for: .normal)
        checkbox2.setBackgroundImage(image2, for: .normal)
        checkbox3.setBackgroundImage(image3, for: .normal)
    }
    
    let pharmacist: UITextField = {
        let pharmacist = UITextField()
        pharmacist.translatesAutoresizingMaskIntoConstraints = false
        pharmacist.text = "Pharmacist"
        pharmacist.isUserInteractionEnabled = false
        pharmacist.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        pharmacist.textColor = UIColor.white
        return pharmacist
    }()
    
    lazy var registerButton: UIButton = {
        let register = UIButton()
        register.setTitle("Register", for: .normal)
        register.translatesAutoresizingMaskIntoConstraints = false
        register.addTarget(self, action: #selector(handleRegister), for: .touchUpInside)
        register.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 251/255, alpha: 1)
        return register
    }()
    
    @objc func handleRegister(){
        guard let email = emailTextFiled.text, let password = passwordTextFiled.text, let name = NameTextFiled.text, let age = ageTextFiled.text else {
            print("Form is not valid")
            return
        }
        
        
        if((!chckbox1) && (!chckbox2) && (!chckbox3)){
            print("here")
            return
        }
        
        
        var customer = ""
        
        if(chckbox1){
            customer = "Doctor"
        }
        if(chckbox2){
            customer = "Patient"
        }
        if(chckbox3){
            customer = "Pharmacist"
        }
        
    
           authref.createUser(withEmail: email, password: password, completion: { (user: User?,error) in
         if(error != nil){
         print(error)
         return
         }
         
         guard let uid = user?.uid else {
         return
         }
         
         //successfully created user registered
            self.ref.child("users").child(uid).setValue(["email": email,"password": password,"name": name, "age": age,"occupation":customer,"uid":uid])
         
            let preferences = UserDefaults.standard
            let currentLevel = customer
            let currentLevelKey = "currentLevel"
            preferences.set(currentLevel, forKey: currentLevelKey)
            preferences.synchronize()
            
            
            if(customer == "Patient"){
                self.ref.child("patients").child(uid).setValue(["email": email,"name": name, "age": age,"uid":uid])
            }
            
            if(customer == "Doctor"){
                self.ref.child("doctors").child(uid).setValue(["name": name,"uid":uid])
            }
            if(customer == "Pharmacist"){
                self.ref.child("pharmacists").child(uid).setValue(["name":name,"uid":uid,"email":email])
            }
            
         let profileController = ProfileViewController()
         let navCotroller = UINavigationController(rootViewController: profileController)
         self.present(navCotroller, animated: true, completion: nil)
         })
        
    }
    
    func setConstraintsContainerView(){
        inputContainerView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        inputContainerView.bottomAnchor.constraint(equalTo: view.centerYAnchor,constant:-20).isActive = true
        inputContainerView.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -24).isActive = true
        inputContainerView.heightAnchor.constraint(equalToConstant: 240).isActive = true
        
        
        inputContainerView.addSubview(NameTextFiled)
        inputContainerView.addSubview(seperatorView)
        inputContainerView.addSubview(emailTextFiled)
        inputContainerView.addSubview(seperatorView2)
        inputContainerView.addSubview(passwordTextFiled)
        inputContainerView.addSubview(seperatorView3)
        inputContainerView.addSubview(ageTextFiled)
        
        NameTextFiled.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        NameTextFiled.topAnchor.constraint(equalTo: inputContainerView.topAnchor, constant: 6).isActive = true
        NameTextFiled.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor, constant: -12).isActive = true
        NameTextFiled.heightAnchor.constraint(equalTo: inputContainerView.heightAnchor, multiplier: 1/5).isActive = true
        
        seperatorView.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        seperatorView.topAnchor.constraint(equalTo: NameTextFiled.bottomAnchor, constant: 6).isActive = true
        seperatorView.widthAnchor.constraint(equalTo: NameTextFiled.widthAnchor).isActive = true
        seperatorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        
        emailTextFiled.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        emailTextFiled.topAnchor.constraint(equalTo: seperatorView.bottomAnchor, constant: 6).isActive = true
        emailTextFiled.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor, constant: -12).isActive = true
        emailTextFiled.heightAnchor.constraint(equalTo: inputContainerView.heightAnchor, multiplier: 1/5).isActive = true
        
        seperatorView2.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        seperatorView2.topAnchor.constraint(equalTo: emailTextFiled.bottomAnchor, constant: 6).isActive = true
        seperatorView2.widthAnchor.constraint(equalTo: emailTextFiled.widthAnchor).isActive = true
        seperatorView2.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        
        passwordTextFiled.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        passwordTextFiled.topAnchor.constraint(equalTo: seperatorView2.topAnchor, constant: 6).isActive = true
        passwordTextFiled.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor, constant: -12).isActive = true
        passwordTextFiled.heightAnchor.constraint(equalTo: inputContainerView.heightAnchor, multiplier: 1/5).isActive = true
        
        seperatorView3.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        seperatorView3.topAnchor.constraint(equalTo: passwordTextFiled.bottomAnchor, constant: 6).isActive = true
        seperatorView3.widthAnchor.constraint(equalTo: passwordTextFiled.widthAnchor).isActive = true
        seperatorView3.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        ageTextFiled.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 10).isActive = true
        ageTextFiled.topAnchor.constraint(equalTo: seperatorView3.topAnchor, constant: 6).isActive = true
        ageTextFiled.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor, constant: -12).isActive = true
        ageTextFiled.heightAnchor.constraint(equalTo: inputContainerView.heightAnchor, multiplier: 1/5).isActive = true
    }
    
    
    
    func setConstraintsCheckbox1(){
        checkbox1.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 20).isActive = true
        checkbox1.topAnchor.constraint(equalTo: inputContainerView.bottomAnchor, constant: 10).isActive = true
        checkbox1.widthAnchor.constraint(equalToConstant: 20).isActive = true
        checkbox1.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }
    
    func setConstraintsDoctor(){
        doctor.leftAnchor.constraint(equalTo: checkbox1.rightAnchor, constant: 20).isActive = true
        doctor.topAnchor.constraint(equalTo: inputContainerView.bottomAnchor, constant: 10).isActive = true
        doctor.widthAnchor.constraint(equalToConstant: 100).isActive = true
        doctor.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }
    func setConstraintsCheckbox2(){
        checkbox2.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 20).isActive = true
        checkbox2.topAnchor.constraint(equalTo: checkbox1.bottomAnchor, constant: 10).isActive = true
        checkbox2.widthAnchor.constraint(equalToConstant: 20).isActive = true
        checkbox2.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }
    
    func setConstraintsPatient(){
        patient.leftAnchor.constraint(equalTo: checkbox2.rightAnchor, constant: 20).isActive = true
        patient.topAnchor.constraint(equalTo: doctor.bottomAnchor, constant: 10).isActive = true
        patient.widthAnchor.constraint(equalToConstant: 100).isActive = true
        patient.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }
    
    func setConstraintsCheckbox3(){
        checkbox3.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 20).isActive = true
        checkbox3.topAnchor.constraint(equalTo: checkbox2.bottomAnchor, constant: 10).isActive = true
        checkbox3.widthAnchor.constraint(equalToConstant: 20).isActive = true
        checkbox3.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }
    
    func setConstraintsPharmacist(){
        pharmacist.leftAnchor.constraint(equalTo: checkbox3.rightAnchor, constant: 20).isActive = true
        pharmacist.topAnchor.constraint(equalTo: patient.bottomAnchor, constant: 10).isActive = true
        pharmacist.widthAnchor.constraint(equalToConstant: 100).isActive = true
        pharmacist.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }
    
    func setConstraintsRegisterButton(){
        registerButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        registerButton.topAnchor.constraint(equalTo: pharmacist.bottomAnchor, constant: 10).isActive = true
        registerButton.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor).isActive = true
        registerButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
}
