//
//  PatientDetailViewController.swift
//  BeWell
//
//  Created by toppy on 4/15/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase
import UserNotifications


class PatientDetailViewController: UIViewController,UITextFieldDelegate  {
    var patient: PatientModel?
    var prescriptions = [eachPrescription]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

          view.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        
        self.setupviews()
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
        
        Database.database().reference().child("doctors").child(uid).child((patient?.uid)!).observe(.childAdded, with: { (snapshot) in
            
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                
                let prescription = eachPrescription(dictionary: dictionary)
                self.prescriptions.append(prescription)
                self.setupTableView()
                self.tableview.reloadingData()
            }
            
        }, withCancel: nil)
        
        
        details.disease.delegate = self
        details.pill.delegate = self
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        
        details.disease.resignFirstResponder()
        details.pill.resignFirstResponder()
        
        return true
    }
    
 
    let header : PatientHeader = {
        let header = PatientHeader()
        header.translatesAutoresizingMaskIntoConstraints = false
        return header
    }()
    
    let details : PatientDetails = {
        let details = PatientDetails()
        details.translatesAutoresizingMaskIntoConstraints = false
        return details
    }()
    
    let donebutton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitle("Done", for: .normal)
        button.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 251/255, alpha: 1)
        button.addTarget(self, action: #selector(handleDone), for: .touchUpInside)
        return button
    }()
    
    @objc func handleDone(){

        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
       
        if(details.disease.text == "" || details.pill.text == "" || details.hour.text == ""){
            return
        }
        
        
       let ct = Int64(NSDate().timeIntervalSince1970 * 1000)
        print(ct)
        let value = ["disease":details.disease.text!,"pill":details.pill.text!,"time":details.hour.text,"timestamp":String(ct)] as [String : Any]
        Database.database().reference().child("doctors").child(uid).child((patient?.uid)!).child(String(ct)).updateChildValues(value, withCompletionBlock: { (err, ref) in
            if err != nil {
                print(err ?? "")
                return
            }
  Database.database().reference().child("prescriptions").child((self.patient?.uid)!).child(String(ct)).setValue(["disease":self.details.disease.text!,"pill":self.details.pill.text!,"time":self.details.hour.text,"timestamp":String(ct)] as [String : Any])
            self.details.disease.text = ""
            self.details.pill.text = ""
            self.details.hour.text = ""

        })

    }
    
    
    
    let pick : UIButton = {
        let pick = UIButton()
        pick.translatesAutoresizingMaskIntoConstraints = false
        pick.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 251/255, alpha: 1)
        pick.setTitle("Pick", for: .normal)
         pick.addTarget(self, action: #selector(handlePick), for: .touchUpInside)
        pick.setImage(UIImage(named: "calendar"), for: .normal)
        
        return pick
    }()
    
    
     let timePicker = UIDatePicker()
    @objc func handlePick(){
       
        timePicker.datePickerMode = UIDatePickerMode.time
        timePicker.frame = CGRect(x: 0.0, y: (self.view.frame.height/2 + 60), width: self.view.frame.width, height: 150.0)
        timePicker.backgroundColor = UIColor.white
        self.view.addSubview(timePicker)
        timePicker.addTarget(self, action: #selector(self.startTimeDiveChanged), for: UIControlEvents.valueChanged)
    }
  
    
    @objc func startTimeDiveChanged(sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        details.hour.text = formatter.string(from: sender.date)
        timePicker.removeFromSuperview() // if you want to remove time picker
    }
    
    let tableview : Prescriptions = {
        let tableview = Prescriptions()
        tableview.translatesAutoresizingMaskIntoConstraints = false
        return tableview
    }()
    
    func setupviews()
    {
        view.backgroundColor = .white
        view.addSubview(header)
        header.patient = patient
        header.translatesAutoresizingMaskIntoConstraints = false
        header.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20).isActive = true
        header.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        header.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.2).isActive = true
        
        header.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
        header.setupviews()
        
        
        
        view.addSubview(details)
        details.patient = patient
        details.topAnchor.constraint(equalTo: header.bottomAnchor, constant: 20).isActive = true
        details.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        details.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.28).isActive = true
        
        details.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
        
        details.setupviews()
        
        
        view.addSubview(donebutton)
        donebutton.topAnchor.constraint(equalTo: details.bottomAnchor, constant: 10).isActive = true
        donebutton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        // donebutton.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        donebutton.widthAnchor.constraint(equalToConstant: 70).isActive = true
        donebutton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        
        view.addSubview(pick)
        pick.leftAnchor.constraint(equalTo: details.hour.rightAnchor, constant: 10).isActive = true
        pick.topAnchor.constraint(equalTo: details.pill.bottomAnchor, constant: 15).isActive = true
        pick.widthAnchor.constraint(equalToConstant: 25).isActive = true
        pick.heightAnchor.constraint(equalToConstant: 25).isActive = true
        

    }
    
    
    func setupTableView(){
        view.addSubview(tableview)
        tableview.prescriptions = prescriptions
        tableview.patient = patient
        tableview.topAnchor.constraint(equalTo: donebutton.bottomAnchor, constant: 20).isActive = true
        tableview.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20).isActive = true
        tableview.heightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.heightAnchor, multiplier: 0.4).isActive = true
        
        tableview.widthAnchor.constraint(equalTo: view.safeAreaLayoutGuide.widthAnchor).isActive = true
    }
    
    
}


class Prescriptions: UIView, UITableViewDelegate,UITableViewDataSource {
    var prescriptions = [eachPrescription]()
    var patient : PatientModel!
    
    lazy var tableView: UITableView = {
        let tableview = UITableView()
        tableview.translatesAutoresizingMaskIntoConstraints = false
        tableview.register(ListCell1.self, forCellReuseIdentifier: "prescriptioncellid")
        return tableview
    }()
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return prescriptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let prescription = prescriptions[indexPath.row] as? eachPrescription{
            let cell = tableView.dequeueReusableCell(withIdentifier: "prescriptioncellid", for: indexPath) as! ListCell1
   
                cell.time.text = "At: \(prescription.time!)"
            
            cell.textLabel?.text = prescription.disease
            
            
            
            cell.detailTextLabel?.textColor = .black
            cell.detailTextLabel?.text = prescription.pill
            return cell
            
        }
        return UITableViewCell()
    }
    
     func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            
           guard let uid = Auth.auth().currentUser?.uid else{
                return
            }
            if let prescription = prescriptions[indexPath.row] as? eachPrescription{
         Database.database().reference().child("doctors").child(uid).child(patient.uid!).child(prescription.timestamp!).removeValue()
                
                Database.database().reference().child("prescriptions").child((self.patient?.uid)!).child(prescription.timestamp!).removeValue()
            }
 
            tableView.beginUpdates()
            prescriptions.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
            
        }
    }

    
    
    
    func setupViews()
    {
        tableView.dataSource = self
        tableView.delegate = self
        tableView.backgroundColor = .clear
        
        addSubview(tableView)

        addConstraintsWithFormat("H:|[v0]|", views: tableView)
        
        addConstraintsWithFormat("V:|[v0]|", views: tableView)
        
        
    }
    
    
    func reloadingData(){
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
 
}

class ListCell1: UITableViewCell{
    override func layoutSubviews() {
        super.layoutSubviews()
        textLabel?.frame=CGRect(x:15,y:textLabel!.frame.origin.y - 2, width:
            textLabel!.frame.width,height:textLabel!.frame.height)
        detailTextLabel?.frame=CGRect(x:20,y:detailTextLabel!.frame.origin.y + 2 ,width:
            detailTextLabel!.frame.width,height:detailTextLabel!.frame.height)
    }
    
    var time : UILabel = {
        let time = UILabel()
        time.translatesAutoresizingMaskIntoConstraints = false
       
        return time
    }()
    
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        addSubview(time)
        
        time.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -30).isActive=true
        time.centerYAnchor.constraint(equalTo: self.centerYAnchor ).isActive=true

        time.widthAnchor.constraint(equalToConstant: 120).isActive=true
        time.heightAnchor.constraint(equalToConstant: 40).isActive=true
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

