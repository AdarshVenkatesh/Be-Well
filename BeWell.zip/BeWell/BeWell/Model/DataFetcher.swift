//
//  DataFetcher.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import GoogleMaps
import GooglePlaces
import CoreLocation


typealias PlacesCompletion = ([FetchPlace]) -> Void

class DataFetcher {
    private var placesTask: URLSessionDataTask?
    private var session: URLSession {
        return URLSession.shared
    }
    let googleApiKey = "AIzaSyDAn-jacL7loHkyygz4Yb--M8HWee1_EXw"
    
    func fetchPlacesNearCoordinate(_ coordinate: CLLocationCoordinate2D, radius: Double, type: String, completion: @escaping PlacesCompletion) -> Void {
        var urlString = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=\(coordinate.latitude),\(coordinate.longitude)&radius=\(radius)&rankby=prominence&sensor=true&key=\(googleApiKey)"
        
        urlString += "&types=\(type)"
        urlString = urlString.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed) ?? urlString
        
        guard let url = URL(string: urlString) else {
            completion([])
            return
        }
        
        if let task = placesTask, task.taskIdentifier > 0 && task.state == .running {
            task.cancel()
        }
        
        // update main UI thread
        DispatchQueue.main.async {
            UIApplication.shared.isNetworkActivityIndicatorVisible = true
        }
        
        placesTask = session.dataTask(with: url) { data, response, error in
            var placesArray: [FetchPlace] = []
            
            // defer completion task for URLSession, then update main UI thread
            defer {
                DispatchQueue.main.async {
                    UIApplication.shared.isNetworkActivityIndicatorVisible = false
                    completion(placesArray)
                }
            }
            
            // USE SwiftyJSON
            guard let data = data,
                let json = try? JSON(data: data, options: .mutableContainers),
                let results = json["results"].arrayObject as? [[String: Any]] else {
                    return
            }
            
            //print(results)
            
            results.forEach({ (place) in
                //let json = JSON(place)
                print(json)
                if let types = json["types"].arrayObject as? [String] {
                    for found in types {
                        if found == type {
                            let place = FetchPlace(name: json["name"].stringValue, placeid: json["place_id"].stringValue, address: json["vicinity"].stringValue, coordinate:  CLLocationCoordinate2DMake(json["geometry"]["location"]["lat"].doubleValue, json["geometry"]["location"]["lng"].doubleValue), placeType: type, photoref: json["photos"][0]["photo_reference"].stringValue, rating: json["rating"].doubleValue)
                            placesArray.append(place)
                            
                            break
                        }
                    }
                }
            })
        }
        placesTask?.resume()
    }
}
