//
//  UserModel.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/13/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class UserModel: NSObject {

    var email: String?
    var password: String?
    var name: String?
    var age: String?
    var imageurl: String?
    var occupation: String?
    var uid: String?
    
    init(dictionary: [String: AnyObject]) {
        
        self.name = dictionary["name"] as? String
        self.email = dictionary["email"] as? String
        self.password = dictionary["password"] as? String
        self.age = dictionary["age"] as? String
        self.imageurl = dictionary["imageurl"] as? String
        self.occupation = dictionary["occupation"] as? String
        self.uid = dictionary["uid"] as? String
    }
    
}
