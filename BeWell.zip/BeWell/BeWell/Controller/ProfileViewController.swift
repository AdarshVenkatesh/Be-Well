//
//  ProfileViewController.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/13/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class ProfileViewController: UIViewController , UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var ref: DatabaseReference!
    var authref: Auth!
    var dictionary = Dictionary<String, Any>()
    var profileurl: String!
    var emailIs: String!
    var nameIs: String!
    var ageIs: String!
    var passwordIs: String!
    var currentLevel: String?
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.white
        
          self.navigationItem.title = "User Profile"
        
        ref  = Database.database().reference()
        authref = Auth.auth()
        
       setupNavBar()
        
        view.addSubview(container)
        view.addSubview(imageView)
        
        setconstarintsStackview()
         setconstarintsImageView()
        
        let uid = authref.currentUser?.uid
        
        let childref = ref.child("users").child(uid!)
        
        childref.observeSingleEvent(of: .value, with: { (snapshot) in
            
            if let dictionary = snapshot.value as? [String: AnyObject] {
                
                
                let user = UserModel(dictionary: dictionary)
                
                self.setupProfileWithUser(user: user)
                
                self.nameIs = user.name
                self.emailIs = user.email
                self.ageIs = user.age
                self.passwordIs = user.password
              
            }
            
        }, withCancel: nil)
    }
    
    
    func setupNavBar(){
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(handlelogout))
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(handleDone))
        navigationItem.leftBarButtonItem?.tintColor = UIColor.white
        navigationItem.rightBarButtonItem?.tintColor = UIColor.white
    }

    @objc func handlelogout(){
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        
        let login = LoginViewController()
        let navCotroller = UINavigationController(rootViewController: login)
        present(navCotroller, animated: true, completion: nil)
    }
    
    
    @objc func handleDone(){
        let preferences = UserDefaults.standard
        
        let currentLevelKey = "currentLevel"
        if preferences.object(forKey: currentLevelKey) == nil {
            print("doesn't exist")
        } else {
            currentLevel = preferences.string(forKey: currentLevelKey)
            print("string is:",currentLevel)
        }
        
        if(currentLevel == "Doctor"){
            let profController = PatientsListTableViewController()
            let navCotroller = UINavigationController(rootViewController: profController)
            self.present(navCotroller, animated: true, completion: nil)
        }
        
        if(currentLevel == "Patient"){
            let profController = PatientHomeViewController()
            let navCotroller = UINavigationController(rootViewController: profController)
            self.present(navCotroller, animated: true, completion: nil)
        }
        
        if(currentLevel == "Pharmacist"){
            let ordersController = PharmaOrdersTableViewController()
            let navCotroller = UINavigationController(rootViewController: ordersController)
            self.present(navCotroller, animated: true, completion: nil)
        }

    }
    
    
    func setupProfileWithUser(user: UserModel){
        profileStack.userModel = user
        if let url = user.imageurl {
            imageView.downloadimageUsingcacheWithLink(url)
        }
    }

    
    let container: UIView = {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false
        container.backgroundColor = UIColor.orange
        container.layer.cornerRadius = 5
        container.layer.masksToBounds = true
        return container
    }()
    
    let profileStack:ProfileView = {
        
        let profileStack = ProfileView()
        profileStack.translatesAutoresizingMaskIntoConstraints = false;
        return profileStack
    }()
    
    
    lazy var imageView: UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.image = UIImage(named: "defimage")
        image.contentMode = .scaleAspectFill
        image.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleSelectProfileImageView)))
        image.isUserInteractionEnabled = true
        image.layer.cornerRadius = 80
        image.clipsToBounds = true
        return image
    }()
    
    
    @objc func handleSelectProfileImageView() {
       
        let alert = UIAlertController(title: "Photo", message: "Take or Choose Photo", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Use Camera", style: .default, handler: selectCamera))
        alert.addAction(UIAlertAction(title: "Use Gallery", style: .default, handler: selectGallery))
        present(alert, animated: true, completion: nil)

    }
    
    func selectCamera(alert: UIAlertAction!){
        if UIImagePickerController.isSourceTypeAvailable(.camera) {
            var imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.allowsEditing = false
            imagePicker.navigationItem.rightBarButtonItem?.tintColor = .white
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func selectGallery(alert: UIAlertAction!){
        let picker = UIImagePickerController()
        
        picker.delegate = self
        picker.allowsEditing = true
        picker.navigationItem.rightBarButtonItem?.tintColor = .white
        picker.navigationBar.tintColor = .white
        present(picker, animated: true, completion: nil)
    }
    
    // UIImagePickerController Delegates!!!
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        var selectedImageFromPicker: UIImage?
        
        if let editedImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            selectedImageFromPicker = editedImage
        } else if let originalImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            
            selectedImageFromPicker = originalImage
        }
        
        if let selectedImage = selectedImageFromPicker {
            imageView.image = selectedImage
        }
        
        dismiss(animated: true, completion: nil)
        handleUpdate()
    }

    
    @objc func handleUpdate() {
        
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
        //successfully authenticated user
        
        // upload profile image
        let imageName = UUID().uuidString
        let storageRef = Storage.storage().reference().child("profile_images").child("\(imageName).jpg")
        
        // Compress Image into JPEG type
        if let profileImage = self.imageView.image, let uploadData = UIImageJPEGRepresentation(profileImage, 0.1) {
            
            _ = storageRef.putData(uploadData, metadata: nil) { (metadata, error) in
                guard let metadata = metadata else {
                    // Uh-oh, an error occurred!
                    print("Error when uploading profile image")
                    return
                }
                // Metadata contains file metadata such as size, content-type, and download URL.
                self.profileurl = metadata.downloadURL()?.absoluteString
                self.registerUserIntoDatabaseWithUID(uid)
            }
        }
    }
    
    fileprivate func registerUserIntoDatabaseWithUID(_ uid: String) {
        let ref = Database.database().reference()
        let usersReference = ref.child("users").child(uid)
        
        let values = ["email":emailIs as AnyObject,"password": passwordIs,"name": nameIs, "age": ageIs, "imageurl": profileurl] as [String : AnyObject]
        
        usersReference.updateChildValues(values, withCompletionBlock: { (err, ref) in
            if err != nil {
                print(err ?? "")
                return
            }
        })
        
        let preferences = UserDefaults.standard
        
        let currentLevelKey = "currentLevel"
        if preferences.object(forKey: currentLevelKey) == nil {
            print("doesn't exist")
        } else {
            currentLevel = preferences.string(forKey: currentLevelKey)
            print("string is:",currentLevel)
        }
        
        if(currentLevel == "Doctor"){
            let value = ["imageurl":profileurl] as [String:AnyObject]
            
            ref.child("doctors").child(uid).updateChildValues(value, withCompletionBlock: { (err, ref) in
                if err != nil {
                    print(err ?? "")
                    return
                }
            })
        }
        
        if(currentLevel == "Patient"){
            let value = ["imageurl":profileurl] as [String:AnyObject]
            
            ref.child("patients").child(uid).updateChildValues(value, withCompletionBlock: { (err, ref) in
                if err != nil {
                    print(err ?? "")
                    return
                }
            })
            
        }
        
        if(currentLevel == "Pharmacist"){
            let value = ["imageurl":profileurl] as [String:AnyObject]
            
            ref.child("pharmacists").child(uid).updateChildValues(value, withCompletionBlock: { (err, ref) in
                if err != nil {
                    print(err ?? "")
                    return
                }
            })
        }
        
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("canceled picker")
        dismiss(animated: true, completion: nil)
    }
    
    
    func setconstarintsStackview(){
        
        container.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        container.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 100).isActive = true
        container.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -24).isActive = true
        container.heightAnchor.constraint(equalToConstant: 250).isActive = true
        
        
        container.addSubview(profileStack)
        
        profileStack.leftAnchor.constraint(equalTo: container.leftAnchor, constant: 12).isActive = true
        profileStack.topAnchor.constraint(equalTo: container.topAnchor).isActive = true
        profileStack.widthAnchor.constraint(equalTo: container.widthAnchor, constant: -10).isActive = true
        profileStack.heightAnchor.constraint(equalToConstant: 200).isActive = true
    }
    
    func  setconstarintsImageView(){
        imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: container.topAnchor, constant: -50).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 150).isActive = true
    }
    
}





let imageCache=NSCache<NSString,AnyObject>()
extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIViewContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func downloadedFrom(link: String, contentMode mode: UIViewContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
    func downloadimageUsingcacheWithLink(_ urlLink: String){
        self.image=nil
        if urlLink.isEmpty{
            return
        }
        if let cachedImage=imageCache.object(forKey: urlLink as NSString)as? UIImage{
            self.image=cachedImage
            return
        }
        let url=URL(string:urlLink)
        URLSession.shared.dataTask(with: url!,completionHandler:{(data,response,error) in
            if let err=error{
                print("The erroe is:",err)
                return
            }
            DispatchQueue.main.async {
                if let newImage=UIImage(data:data!){
                    
                    imageCache.setObject(newImage, forKey: urlLink as NSString)
                    
                    self.image=newImage
                    
                }
            }
        }).resume()
    }
}














