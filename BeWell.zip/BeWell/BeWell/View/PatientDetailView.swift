//
//  PatientDetailView.swift
//  BeWell
//
//  Created by toppy on 4/15/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PatientHeader: UIView {
    
    var patient:PatientModel?{
        
        didSet{
            patientName.text = patient?.name
            if(patient?.imageurl != nil){
                imageView.downloadimageUsingcacheWithLink((patient?.imageurl)!)
            }
            
        }
    }

    let patientNameLabel : UILabel = {
        let label = UILabel()
        label.text = "Patient:"
        label.textAlignment =  NSTextAlignment.justified
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 20)
        return label
    }()
    
    let patientName : UILabel = {
        let label = UILabel()
        label.text = "Patient"
        label.textAlignment =  NSTextAlignment.justified
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 20)
        return label
    }()
    
    let imageView: UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.image = UIImage(named: "defimage")
        image.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        image.contentMode = .scaleAspectFit
        return image
    }()
    
    
    
     func setupviews(){
        
        let stackview : UIStackView = {
            let stackview = UIStackView()
            stackview.axis  = UILayoutConstraintAxis.horizontal
            stackview.distribution  = .fill
            stackview.alignment = UIStackViewAlignment.fill
            stackview.spacing   = 1
            stackview.translatesAutoresizingMaskIntoConstraints = false
            stackview.heightAnchor.constraint(equalToConstant: 20)
            stackview.addArrangedSubview(patientNameLabel)
            stackview.addArrangedSubview(patientName)
            return stackview
        }()
        addSubview(stackview)
        addConstraintsWithFormat("H:|[v0]|", views: stackview)
        addConstraintsWithFormat("H:|-10-[v0]-10-[v1(200)]|", views: patientNameLabel,patientName)
        addConstraintsWithFormat("V:|[v0]|", views: stackview)
        
 
        let stackview1 : UIStackView = {
            let stackview = UIStackView()
            stackview.axis  = UILayoutConstraintAxis.vertical
            stackview.distribution  = .fillProportionally
            stackview.alignment = UIStackViewAlignment.center
            stackview.spacing   = 1
            stackview.translatesAutoresizingMaskIntoConstraints = false
            stackview.heightAnchor.constraint(equalToConstant: 10)
            stackview.addArrangedSubview(stackview)
            stackview.addArrangedSubview(imageView)
            return stackview
        }()
        
        addSubview(stackview1)
        addConstraintsWithFormat("H:|[v0]|", views: imageView)
        addConstraintsWithFormat("H:|[v0]|", views: stackview1)
        addConstraintsWithFormat("V:|-5-[v0(20)]-10-[v1(100)]-5-|", views: stackview,imageView)
  
    }
}
    class PatientDetails: UIView {
        var patient:PatientModel?{
            
            didSet{
                age.text = patient?.age  
            }
        }
        let agelabel: UILabel = {
            let agelabel = UILabel()
            agelabel.translatesAutoresizingMaskIntoConstraints = false;
            agelabel.text = "Age:"
            agelabel.font = agelabel.font.withSize(20)
            return agelabel
        }()
        
        
        let age: UILabel = {
            let age = UILabel()
            age.translatesAutoresizingMaskIntoConstraints = false
            age.font = age.font.withSize(20)
            age.text = "age"
            return age
        }()
        
        let diseaselabel: UILabel = {
            let diseaselabel = UILabel()
            diseaselabel.translatesAutoresizingMaskIntoConstraints = false;
            diseaselabel.text = "Disease:"
            diseaselabel.font = diseaselabel.font.withSize(20)
          
            diseaselabel.contentMode = .scaleAspectFit
            return diseaselabel
        }()
        
        let disease: UITextField = {
            let disease = UITextField()
            disease.translatesAutoresizingMaskIntoConstraints = false
            disease.placeholder = "disease"
            disease.backgroundColor = UIColor.lightGray
            disease.returnKeyType = UIReturnKeyType.done
            disease.layer.cornerRadius = 5
            disease.layer.masksToBounds = true
            disease.text = ""
            disease.returnKeyType = UIReturnKeyType.done
            return disease
        }()
        
        let pilllabel: UILabel = {
            let pilllabel = UILabel()
            pilllabel.translatesAutoresizingMaskIntoConstraints = false;
            pilllabel.text = "Pill:"
            pilllabel.font = pilllabel.font.withSize(20)     
            pilllabel.contentMode = .scaleAspectFit
            return pilllabel
        }()
        
        let pill: UITextField = {
            let pill = UITextField()
            pill.translatesAutoresizingMaskIntoConstraints = false
            pill.placeholder = "pill"
            pill.backgroundColor = UIColor.lightGray
            pill.returnKeyType = UIReturnKeyType.done
            pill.layer.cornerRadius = 5
            pill.layer.masksToBounds = true
           pill.text = ""
            pill.returnKeyType = UIReturnKeyType.done
            return pill
        }()
        
        
        let hourlabel: UILabel = {
            let hourlabel = UILabel()
            hourlabel.translatesAutoresizingMaskIntoConstraints = false;
            hourlabel.text = "Time:"
            hourlabel.font = hourlabel.font.withSize(20)
            
            hourlabel.contentMode = .scaleAspectFit
            return hourlabel
        }()
        
        let hour: UITextField = {
            let hour = UITextField()
            hour.translatesAutoresizingMaskIntoConstraints = false
            hour.placeholder = "time"
            hour.backgroundColor = UIColor.lightGray
            hour.returnKeyType = UIReturnKeyType.done
            hour.layer.cornerRadius = 5
            hour.layer.masksToBounds = true
             hour.text = ""
            return hour
        }()
        

        func setupviews(){
            
            
            addSubview(agelabel)
            agelabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
            agelabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
            agelabel.widthAnchor.constraint(equalToConstant: 70).isActive = true
            agelabel.heightAnchor.constraint(equalToConstant: 20).isActive = true
            
            addSubview(age)
            age.leftAnchor.constraint(equalTo: agelabel.rightAnchor, constant: 20).isActive = true
            age.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
            age.widthAnchor.constraint(equalToConstant: 90).isActive = true
            age.heightAnchor.constraint(equalToConstant: 20).isActive = true
            
            
            addSubview(diseaselabel)
            diseaselabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
            diseaselabel.topAnchor.constraint(equalTo: agelabel.bottomAnchor, constant: 10).isActive = true
            diseaselabel.widthAnchor.constraint(equalToConstant: 100).isActive = true
            diseaselabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
            
            addSubview(disease)
            disease.leftAnchor.constraint(equalTo: diseaselabel.rightAnchor, constant: 20).isActive = true
            disease.topAnchor.constraint(equalTo: age.bottomAnchor, constant: 10).isActive = true
            disease.widthAnchor.constraint(equalToConstant: 150).isActive = true
            disease.heightAnchor.constraint(equalToConstant: 30).isActive = true
            
            
            addSubview(pilllabel)
            pilllabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
            pilllabel.topAnchor.constraint(equalTo: diseaselabel.bottomAnchor, constant: 10).isActive = true
            pilllabel.widthAnchor.constraint(equalToConstant: 70).isActive = true
            pilllabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
            
            addSubview(pill)
            pill.leftAnchor.constraint(equalTo: pilllabel.rightAnchor, constant: 20).isActive = true
            pill.topAnchor.constraint(equalTo: disease.bottomAnchor, constant: 10).isActive = true
            pill.widthAnchor.constraint(equalToConstant: 150).isActive = true
            pill.heightAnchor.constraint(equalToConstant: 30).isActive = true
            
            addSubview(hourlabel)
            hourlabel.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 10).isActive = true
            hourlabel.topAnchor.constraint(equalTo: pilllabel.bottomAnchor, constant: 10).isActive = true
            hourlabel.widthAnchor.constraint(equalToConstant: 70).isActive = true
            hourlabel.heightAnchor.constraint(equalToConstant: 30).isActive = true
            
            addSubview(hour)
            hour.leftAnchor.constraint(equalTo: hourlabel.rightAnchor, constant: 20).isActive = true
            hour.topAnchor.constraint(equalTo: pill.bottomAnchor, constant: 10).isActive = true
            hour.widthAnchor.constraint(equalToConstant: 150).isActive = true
            hour.heightAnchor.constraint(equalToConstant: 30).isActive = true
            

        }
    }


