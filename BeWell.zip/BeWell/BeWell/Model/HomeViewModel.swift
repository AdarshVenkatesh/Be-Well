//
//  HomeViewModel.swift
//  BeWell
//
//  Created by toppy on 5/2/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import Foundation
import UIKit

struct HomeModel {
    var imageName: String?
    var name: String?
    var descrip: String?
    
}
