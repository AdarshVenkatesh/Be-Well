//
//  VideoModel.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import Foundation

// Decodable Data Model for downloaded playlist data

struct VideoResults: Decodable {
    let etag: String?
    let items: [VideoItem]
}

struct VideoItem: Decodable {
    let id: String?
    let snippet: Snippet?
}

struct Snippet: Decodable {
    struct ResourceId: Decodable {
        let kind: String?
        let videoId: String?
    }
    
    struct ThumbNailInfo: Decodable {
        let height: Int?
        let width: Int?
        let url: String?
    }
    
    struct ThumbNails: Decodable {
        let medium: ThumbNailInfo?
        let maxres: ThumbNailInfo?
    }
    
    let title: String?
    let channelId: String?
    let channelTitle: String?
    let description: String?
    let publishedAt: String?
    let resourceId: ResourceId?
    let thumbnails: ThumbNails?
}
