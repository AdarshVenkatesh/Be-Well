//
//  DropDown.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

protocol DropDownDelegate: class {
    func dropDownMenu(didSelectType type: String)
}

class DropDownMenu: UIView {
    weak var delegate: DropDownDelegate?
    
    var stackViewHeightAnchor: NSLayoutConstraint?
    
    var stackView: UIStackView!
    
    var open = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let select: UIButton = {
            let btn = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
            
            btn.layer.cornerRadius = btn.frame.height/2
            btn.setTitle("Select Place Type", for: .normal)
            btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
            btn.titleLabel?.textColor = .white
            btn.backgroundColor = UIColor.purple
            
            btn.addTarget(self, action: #selector(selectHandle), for: .touchUpInside)
            return btn
        }()
        
        let bakery: CustomButton = {
            let btn = CustomButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
            btn.setTitle("Bakery", for: .normal)
            btn.addTarget(self, action: #selector(typeHandle), for: .touchUpInside)
            return btn
        }()
        
        let bar: CustomButton = {
            let btn = CustomButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
            btn.setTitle("Bar", for: .normal)
            btn.addTarget(self, action: #selector(typeHandle), for: .touchUpInside)
            return btn
        }()
        
        let cafe: CustomButton = {
            let btn = CustomButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
            btn.setTitle("Cafe", for: .normal)
            btn.addTarget(self, action: #selector(typeHandle), for: .touchUpInside)
            return btn
        }()
        
        let supermarket: CustomButton = {
            let btn = CustomButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
            btn.setTitle("Supermarket", for: .normal)
            btn.addTarget(self, action: #selector(typeHandle), for: .touchUpInside)
            return btn
        }()
        
        let restaurant: CustomButton = {
            let btn = CustomButton(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
            btn.setTitle("Restaurant", for: .normal)
            btn.addTarget(self, action: #selector(typeHandle), for: .touchUpInside)
            return btn
        }()
        
        let buttons = [select, bakery, bar, cafe, supermarket, restaurant]
        stackView = UIStackView(arrangedSubviews: buttons)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.spacing = CGFloat(3)
        stackView.axis = .vertical
        
        self.addSubview(stackView)
        stackView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        stackView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        stackView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
        
        let hgt = open ? 250: 50
        
        stackViewHeightAnchor = stackView.heightAnchor.constraint(equalToConstant: CGFloat(hgt))
        stackViewHeightAnchor?.isActive = true
    }
    
    
    @objc func selectHandle() {
        open = !open
        
        let hgt = open ? 250: 50
        
        
        stackView.removeConstraint(stackViewHeightAnchor!)
        
        stackViewHeightAnchor = stackView.heightAnchor.constraint(equalToConstant: CGFloat(hgt))
        
        stackViewHeightAnchor?.isActive = true
        stackView.layoutIfNeeded()
        
        let types = stackView.arrangedSubviews
        var i = 0
        types.forEach { (btn) in
            if i != 0 {
                UIView.animate(withDuration: 0.5, animations: {
                    btn.isHidden = !btn.isHidden
                    btn.layoutIfNeeded()
                })
            }
            i += 1
        }
        
        
    }
    
    @objc func typeHandle(_ sender: UIButton) {
        if let type = sender.titleLabel?.text {
            print(type)
            delegate?.dropDownMenu(didSelectType: type)
        }
        
        open = !open
        
        let hgt = open ? 250: 50
        
        
        stackView.removeConstraint(stackViewHeightAnchor!)
        
        stackViewHeightAnchor = stackView.heightAnchor.constraint(equalToConstant: CGFloat(hgt))
        
        stackViewHeightAnchor?.isActive = true
        stackView.layoutIfNeeded()
        
        let types = stackView.arrangedSubviews
        var i = 0
        types.forEach { (btn) in
            if i != 0 {
                UIView.animate(withDuration: 0.5, animations: {
                    btn.isHidden = !btn.isHidden
                    btn.layoutIfNeeded()
                })
            }
            i += 1
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width: 200, height: 250)
    }
}

class CustomButton: UIButton {
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .orange
        self.titleLabel?.textColor = .white
        self.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        self.isHidden = true
        self.layer.cornerRadius = self.frame.height/2
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width: 200, height: 40)
    }
}
