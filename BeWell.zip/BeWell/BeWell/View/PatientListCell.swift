//
//  PatientListCell.swift
//  BeWell
//
//  Created by toppy on 4/15/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit


class PatientListCell: UITableViewCell{
    override func layoutSubviews() {
        super.layoutSubviews()
        textLabel?.frame=CGRect(x:70,y:textLabel!.frame.origin.y - 2, width:
            textLabel!.frame.width,height:textLabel!.frame.height)
        detailTextLabel?.frame=CGRect(x:64,y:detailTextLabel!.frame.origin.y + 2 ,width:
            detailTextLabel!.frame.width,height:detailTextLabel!.frame.height)
    }
    
    let iconImageView:UIImageView={
        let imageView=UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints=false
        imageView.layer.cornerRadius=5
        imageView.layer.masksToBounds=true
        imageView.image = UIImage(named: "defimage")
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        addSubview(iconImageView)
        
        iconImageView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 8).isActive=true
        iconImageView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive=true
        iconImageView.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        iconImageView.widthAnchor.constraint(equalToConstant: 40).isActive=true
        iconImageView.heightAnchor.constraint(equalToConstant: 40).isActive=true
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
