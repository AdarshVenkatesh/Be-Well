//
//  OrdersTableViewController.swift
//  BeWell
//
//  Created by toppy on 4/17/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PharmaOrdersTableViewController: UITableViewController,UINavigationControllerDelegate  {
    var ref: DatabaseReference!
    var authref: Auth!
    var orderslist = [OrderModel]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref  = Database.database().reference()
        authref = Auth.auth()
        checkIfUserIsLoggedIn()
        setupNavBar()
        downloadJson()
        tableView.register(OrdersListViewCell.self, forCellReuseIdentifier: "ordercellid")
    }
    
    @objc func downloadJson(){
        orderslist.removeAll()
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
        let pharmacistsref = ref.child("pharmacists").child(uid)
        
        // Event Listener!!!!
        pharmacistsref.observe(.childAdded, with: { (snapshot) in
 
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let order = OrderModel(dictionary: dictionary)
                self.orderslist.append(order)
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
            
        }, withCancel: nil)
        refreshControl?.endRefreshing()
    }
    
    func setupNavBar(){
        navigationItem.title = "Orders"
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(handlelogout))
      //  navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Reload", style: .plain, target: self, action: #selector(downloadJson))
        navigationItem.rightBarButtonItem?.tintColor = UIColor.white
        navigationItem.leftBarButtonItem?.tintColor = UIColor.white
         navigationController?.navigationBar.tintColor = UIColor.white
        
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:  #selector(downloadJson), for: UIControlEvents.valueChanged)
        self.refreshControl = refreshControl
        
    }
    
    
    func checkIfUserIsLoggedIn() {
        // if not sign in, display login screen!!!
        if Auth.auth().currentUser?.uid == nil {
        } else {
            fetchUserAndSetupNavBarTitle()
        }
    }
    
    func fetchUserAndSetupNavBarTitle() {
        guard let uid = Auth.auth().currentUser?.uid else {
            //for some reason uid = nil
            return
        }
        
        // fetch User info! Set up Navigation Bar!
        Database.database().reference().child("users").child(uid).observeSingleEvent(of: .value, with: { (snapshot) in
            if let dictionary = snapshot.value as? [String: AnyObject] {
                let user = UserModel(dictionary: dictionary)
                self.setupNavBarWithUser(user: user)
            }
        }, withCancel: nil)
    }

    func setupNavBarWithUser(user: UserModel) {
        
        //  let titleView = TitleView(frame: CGRect(x: 0, y: 0, width: 150, height: 40))
        let titleView = TitleView(frame: CGRect(x: 0, y:0, width:150,height: 40))
        self.navigationItem.titleView = titleView
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(handleTap))
        
        titleView.isUserInteractionEnabled = true
        
        titleView.addGestureRecognizer(tap)
        
        if let profileImageUrl = user.imageurl {
            titleView.profileImageView.downloadimageUsingcacheWithLink(profileImageUrl)
            
        }
        titleView.nameLabel.text = user.name
        
        // fetchLists()
    }
    
    // When NavBar TitleView is Tapped!!! Edit User Profile!!!
    @objc private func handleTap(){
        let profileController = ProfileViewController()
        navigationController?.pushViewController(profileController, animated: true)
    }
    
    @objc func handlelogout(){
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print ("Error signing out: %@", signOutError)
        }
        
        let login = LoginViewController()
        let navCotroller = UINavigationController(rootViewController: login)
        present(navCotroller, animated: true, completion: nil)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return orderslist.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let order = orderslist[indexPath.row] as? OrderModel{
            let cell = tableView.dequeueReusableCell(withIdentifier: "ordercellid", for: indexPath) as! OrdersListViewCell
            let posterlink = order.patientImageurl
            if(posterlink != nil){
                cell.iconImageView.downloadimageUsingcacheWithLink(posterlink!)
            }
            if (order.notified == "yes"){
            
            cell.notifiedView.image = UIImage(named: "checkboxchecked")
            }
            
            cell.textLabel?.text = order.patientName
            cell.detailTextLabel?.textColor = .black
            cell.detailTextLabel?.text = order.orderDetail
            return cell
            
        }
        return UITableViewCell()
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    
  /*  override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            
            guard let uid = Auth.auth().currentUser?.uid else{
                return
            }
            if let patient = patientslist[indexPath.row] as? PatientModel{
                ref.child("doctors").child(uid).child(patient.uid!).removeValue()
            }
            
            tableView.beginUpdates()
            orderslist.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            tableView.endUpdates()
            
        }
    }*/
    
    
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            if let order = orderslist[indexPath.row] as? OrderModel{
                let ordercontr = OrderDetailViewController()
                ordercontr.order = order
                navigationController?.pushViewController(ordercontr, animated: true)
        }
    }




}
