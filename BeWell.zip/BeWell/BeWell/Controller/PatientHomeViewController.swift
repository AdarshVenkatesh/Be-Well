//
//  PatientHomeViewController.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class PatientHomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    
    var collectionView : UICollectionView?
    let cellId = "homecell"
    let cellspacing: CGFloat = 10
    var homeviews: [HomeModel] = HomeData
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return homeviews.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellId, for: indexPath) as! HomeCollectionViewCell
        cell.autoLayoutCell()
        cell.home = homeviews[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (UIScreen.main.bounds.width - 3 * cellspacing) / 2
        let height = width
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        if(indexPath.row == 1){
            let ViewController = ScanViewController()
            ViewController.view.backgroundColor = UIColor.blue
            ViewController.navigationItem.title = "Scan"
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        if(indexPath.row == 2){
            let ViewController = PatientPrescriptionsTableViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = "Prescriptions"
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        
        if(indexPath.row == 3){
            let ViewController = MapSearchViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = "Maps"
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            let navCotroller = UINavigationController(rootViewController: ViewController)
            self.present(navCotroller, animated: true, completion: nil)
        }
        
        if(indexPath.row == 0){
            let ViewController = PatientOrdersTableViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = "Orders"
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        if(indexPath.row == 4){
            let ViewController = YouTubeVideo()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = "Youtube"
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        
        if(indexPath.row == 6){
            share()
        }
        
        if(indexPath.row == 7){
            let firebaseAuth = Auth.auth()
            do {
                try firebaseAuth.signOut()
            } catch let signOutError as NSError {
                print ("Error signing out: %@", signOutError)
            }
            
            let login = LoginViewController()
            let navCotroller = UINavigationController(rootViewController: login)
            present(navCotroller, animated: true, completion: nil)
        }
        
        
         if(indexPath.row == 5){
            let ViewController = ProfileViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = "Profile"
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout())
        collectionView?.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(collectionView!)
        collectionView?.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        collectionView?.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        collectionView?.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        collectionView?.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        collectionView?.backgroundColor = .white
        
        let collectionFlowLayout = UICollectionViewFlowLayout()
        collectionView?.setCollectionViewLayout(collectionFlowLayout, animated: true)
        collectionFlowLayout.scrollDirection = .vertical
        collectionFlowLayout.sectionInset = UIEdgeInsets(top: 0, left: cellspacing, bottom: 0, right: cellspacing)
        collectionFlowLayout.minimumInteritemSpacing = 10
        collectionFlowLayout.minimumLineSpacing = 10
        collectionView?.register(HomeCollectionViewCell.self, forCellWithReuseIdentifier: cellId)
        collectionView?.delegate = self
        collectionView?.dataSource = self
        
        

        self.view.backgroundColor = UIColor.white
        navigationController?.navigationBar.isTranslucent = false
        
        let titleLabel = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.width - 32, height: view.frame.height))
        titleLabel.text = "Home"
        titleLabel.textColor = UIColor.white
        titleLabel.font = UIFont.systemFont(ofSize: 20)
        navigationItem.titleView = titleLabel
        
        setupNavBarButtons()
    }
    

    
    // instance creation of slideMenu (one time using lazy var)
    lazy var slideMenuLauncherLeft: SlideMenuLauncher = {
        let launcher = SlideMenuLauncher()
        launcher.homeController = self
        launcher.xLeftAnchor = true
        return launcher
    }()
    
    lazy var slideMenuLauncherRight: SlideMenuLauncher = {
        let launcher = SlideMenuLauncher()
        launcher.homeController = self
        launcher.xLeftAnchor = false
        return launcher
    }()
    
    @objc func handleLeftMenu() {
        //show menu
        slideMenuLauncherLeft.showMenus()
    }
    
    func setupNavBarButtons() {
        let menuLeftButton = UIBarButtonItem(image: UIImage(named: "menu")?.withRenderingMode(.alwaysOriginal), style: .plain, target: self, action: #selector(handleLeftMenu))
        navigationItem.leftBarButtonItem = menuLeftButton
    }
    
    func showControllerForSlideMenu(_ menu: SlideMenu) {

        if(menu.name.rawValue == "QR Scan"){
            let ViewController = ScanViewController()
            ViewController.view.backgroundColor = UIColor.blue
            ViewController.navigationItem.title = menu.name.rawValue
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        if(menu.name.rawValue == "Prescriptions"){
            let ViewController = PatientPrescriptionsTableViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = menu.name.rawValue
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        
        if(menu.name.rawValue == "Maps"){
            let ViewController = MapSearchViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = menu.name.rawValue
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            let navCotroller = UINavigationController(rootViewController: ViewController)
            self.present(navCotroller, animated: true, completion: nil)
        }
        
        if(menu.name.rawValue == "Orders"){
            let ViewController = PatientOrdersTableViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = menu.name.rawValue
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        if(menu.name.rawValue == "Youtube"){
            let ViewController = YouTubeVideo()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = menu.name.rawValue
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        
        if(menu.name.rawValue == "Profile"){
            let ViewController = ProfileViewController()
            ViewController.view.backgroundColor = UIColor.white
            ViewController.navigationItem.title = menu.name.rawValue
            navigationController?.navigationBar.tintColor = UIColor.white
            navigationController?.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
            navigationController?.pushViewController(ViewController, animated: true)
        }
        
        if(menu.name.rawValue == "Share This App"){
            share()
        }
        
        
        if(menu.name.rawValue == "Logout"){
            print("logout")
            let firebaseAuth = Auth.auth()
            do {
                try firebaseAuth.signOut()
            } catch let signOutError as NSError {
                print ("Error signing out: %@", signOutError)
            }
            
            let login = LoginViewController()
            let navCotroller = UINavigationController(rootViewController: login)
            present(navCotroller, animated: true, completion: nil)
        }
    }
    
    func share(){
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        let textToShare = "Check out my app"
        
        if let myWebsite = URL(string: "http://itunes.apple.com/app/idXXXXXXXXX") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite, image ?? #imageLiteral(resourceName: "share")] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            
            //Excluded Activities
            activityVC.excludedActivityTypes = [UIActivityType.airDrop, UIActivityType.addToReadingList]
            //
            
          //  activityVC.popoverPresentationController?.sourceView = sender
            self.present(activityVC, animated: true, completion: nil)
        }    }
    
   
}
