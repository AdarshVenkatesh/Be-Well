//
//  PlaceMarker.swift
//  BeWell
//
//  Created by toppy on 4/24/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import GoogleMaps

class PlaceMarker: GMSMarker {
    let place: FetchPlace
    
    init(place: FetchPlace) {
        self.place = place
        
        super.init()
        
        title = place.name
        snippet = place.address
        position = place.coordinate
        groundAnchor = CGPoint(x: 0.5, y: 1)
        appearAnimation = .pop
    }
}
