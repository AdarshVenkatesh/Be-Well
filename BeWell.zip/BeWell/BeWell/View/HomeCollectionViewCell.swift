//
//  HomeCollectionViewCell.swift
//  BeWell
//
//  Created by toppy on 5/2/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    var stackview: UIStackView = UIStackView()
    var imageView: UIImageView = UIImageView()
    var name: UILabel = UILabel()
    var descrip: UILabel = UILabel()
    
    func autoLayoutCell(){
        self.backgroundColor = .white
        self.addSubview(stackview)
        stackview.translatesAutoresizingMaskIntoConstraints = false
        
        stackview.leadingAnchor.constraint(equalTo: contentView.leadingAnchor).isActive = true
        stackview.trailingAnchor.constraint(equalTo: contentView.trailingAnchor).isActive = true
        stackview.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
        stackview.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
        //add image
        stackview.addArrangedSubview(imageView)
        imageView.image = UIImage(named: "share")
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFit
        imageView.heightAnchor.constraint(equalTo: stackview.heightAnchor, multiplier: 2.0/3.0).isActive = true
        //add label name
        stackview.translatesAutoresizingMaskIntoConstraints = false
        stackview.addArrangedSubview(name)
        name.text = "View Name"
        name.font = UIFont.boldSystemFont(ofSize: 16)
        //add label description
        stackview.translatesAutoresizingMaskIntoConstraints = false
        stackview.addArrangedSubview(descrip)
        descrip.text = "View description"
        descrip.font = UIFont.boldSystemFont(ofSize: 15)
        
        stackview.axis = .vertical
        stackview.alignment = .leading
        stackview.distribution = .equalSpacing
        stackview.spacing = 10
        
    }
    
    var home: HomeModel! {
        didSet{
            imageView.image = UIImage(named: home.imageName!)
            name.text = home.name ?? ""
            descrip.text = home.descrip ?? ""
        }
    }
}
