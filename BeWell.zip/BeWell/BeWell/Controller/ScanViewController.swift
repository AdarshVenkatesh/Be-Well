//
//  ScanViewController.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/13/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import AVFoundation
import Firebase

class ScanViewController: UIViewController,AVCaptureMetadataOutputObjectsDelegate {
var video = AVCaptureVideoPreviewLayer()
     let session = AVCaptureSession()
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.brown
        navigationController?.navigationBar.prefersLargeTitles = true
        
        navigationItem.title = "Scan QR Code"
        navigationItem.rightBarButtonItem =  UIBarButtonItem(title: "Retake", style: .plain, target: self, action: #selector(handleRetake))
        let captureDevice = AVCaptureDevice.default(for: AVMediaType.video)
        
        do{
            let input = try AVCaptureDeviceInput(device: captureDevice!)
            session.addInput(input)
        }
        catch{
            print("ERROR")
        }
        
        let output = AVCaptureMetadataOutput()
        session.addOutput(output)
        
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        
        output.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
        
        video = AVCaptureVideoPreviewLayer(session:session)
        video.frame = view.layer.bounds
        view.layer.addSublayer(video)
        
        session.startRunning()
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if metadataObjects != nil && metadataObjects.count != 0
        {
            if let object = metadataObjects[0] as? AVMetadataMachineReadableCodeObject
            {
                if object.type == AVMetadataObject.ObjectType.qr
                {
                    let alert = UIAlertController(title: "QR Code", message: object.stringValue, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "Retake", style: .default,handler: { (nil) in
                        self.session.stopRunning()
                        self.session.startRunning()
                    }))
                    alert.addAction(UIAlertAction(title: "Order", style: .default, handler:{ (nil) in

                        let pharmacontr = PharmasListTableViewController()
                        pharmacontr.url = object.stringValue
                        self.navigationController?.pushViewController(pharmacontr, animated: true)
                    }
                    ))
                    present(alert, animated: true, completion: nil)
                    
                }
            }
        }
        session.stopRunning()
    }
    
    @objc func handleRetake(){
        session.startRunning()
    }


}
