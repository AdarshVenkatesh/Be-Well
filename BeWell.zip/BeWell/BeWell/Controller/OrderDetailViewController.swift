//
//  OrderDetailViewController.swift
//  BeWell
//
//  Created by toppy on 4/17/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit
import Firebase

class OrderDetailViewController: UIViewController {
    
    
    var order : OrderModel?{
        didSet{
            let underlineAttribute = [kCTUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue]
            let underlineAttributedString = NSAttributedString(string: (order?.orderDetail)!, attributes: underlineAttribute as [NSAttributedStringKey : Any])
            urlLabel.text = underlineAttributedString.string
           //urlLabel.text = order?.orderDetail
            
            if(order?.patientImageurl != nil){
                imageView.downloadimageUsingcacheWithLink((order?.patientImageurl)!)
            }
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.white
   
        setupviews()
    }
    
    
    let urlLabel : UILabel = {
        let label = UILabel()
        label.text = "Click to Notify the Customer"
       // label.textAlignment =  NSTextAlignment.justified
        label.translatesAutoresizingMaskIntoConstraints = false
      //  label.font = UIFont.boldSystemFont(ofSize: 15)
        label.isUserInteractionEnabled = false
        return label
    }()
    
    let openUrl : UIButton = {
        let openUrl = UIButton()
   
       // openUrl.setTitle("open url", for: .normal)
        openUrl.setImage(UIImage(named: "open"), for: .normal)
        openUrl.translatesAutoresizingMaskIntoConstraints = false
        openUrl.addTarget(self, action: #selector(handleOpenurl), for: .touchUpInside)
        return openUrl
    }()
    
    lazy var imageView: UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.image = UIImage(named: "defimage")
        image.contentMode = .scaleAspectFill
        image.isUserInteractionEnabled = true
        return image
    }()
    
    
    let notifyLabel : UILabel = {
        let label = UILabel()
        label.text = "Click Notify the Customer"
        label.textAlignment =  NSTextAlignment.justified
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.boldSystemFont(ofSize: 20)
        label.isUserInteractionEnabled = false
        return label
    }()
    
    
    let notify : UIButton = {
        let notify = UIButton()
        notify.layer.cornerRadius = 10
        notify.clipsToBounds = true
        notify.setImage(UIImage(named: "notify"), for: .normal)
        notify.translatesAutoresizingMaskIntoConstraints = false
        notify.addTarget(self, action: #selector(handleNotify), for: .touchUpInside)
        return notify
    }()
    
    
    @objc func handleOpenurl(){
        UIApplication.shared.openURL(URL(string: (order?.orderDetail)!)!)
    }
    
    @objc func handleNotify(){
        
        guard let uid = Auth.auth().currentUser?.uid else{
            return
        }
 Database.database().reference().child("notifications").child((order?.patientuid)!).child((order?.orderId)!).setValue(["orderId":order?.orderId,"orderDetail":order?.orderDetail,"notified":"no"])
        
        Database.database().reference().child("pharmacists").child(uid).child((order?.orderId)!).updateChildValues(["notified":"yes"])
        
        
    }
    
    func setupviews(){
        
        view.addSubview(notify)
        notify.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        notify.centerYAnchor.constraint(equalTo: view.centerYAnchor,constant:100).isActive = true
        notify.widthAnchor.constraint(equalToConstant: 120).isActive = true
        notify.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        view.addSubview(notifyLabel)
        notifyLabel.bottomAnchor.constraint(equalTo: notify.topAnchor, constant: -30).isActive = true
        notifyLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        notifyLabel.widthAnchor.constraint(equalToConstant: 280).isActive = true
        notifyLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        
        view.addSubview(openUrl)
        openUrl.bottomAnchor.constraint(equalTo: notifyLabel.topAnchor, constant: -30).isActive = true
        openUrl.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        openUrl.widthAnchor.constraint(equalToConstant: 100).isActive = true
        openUrl.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        view.addSubview(urlLabel)
        urlLabel.bottomAnchor.constraint(equalTo: openUrl.topAnchor, constant: -30).isActive = true
        urlLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        urlLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
        urlLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        urlLabel.textAlignment =  NSTextAlignment.justified
        
        
        view.addSubview(imageView)
        imageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        imageView.bottomAnchor.constraint(equalTo: urlLabel.topAnchor, constant: -20).isActive = true
        imageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        imageView.heightAnchor.constraint(equalToConstant: 150).isActive = true
    }
    
    
    
}
