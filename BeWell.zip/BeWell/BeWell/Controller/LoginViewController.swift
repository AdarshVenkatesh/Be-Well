//
//  ViewController.swift
//  BeWell
//
//  Created by Adarsh Venkatesh Bodineni on 4/12/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//


import UIKit
import Firebase
import UserNotifications
import Foundation
import LocalAuthentication

class LoginViewController: UIViewController,UITextFieldDelegate {
    var ref: DatabaseReference!
    var authref: Auth!
    var currentLevel: String?
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
           view.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        
        ref = Database.database().reference()
        authref = Auth.auth()
        
         if authref?.currentUser != nil  {
            
            let preferences = UserDefaults.standard
            
            let currentLevelKey = "currentLevel"
            if preferences.object(forKey: currentLevelKey) == nil {
                print("doesn't exist")
            } else {
                currentLevel = preferences.string(forKey: currentLevelKey)
                print("string is:",currentLevel)
            }
            
            if(currentLevel == "Doctor"){
                let profController = PatientsListTableViewController()
                let navCotroller = UINavigationController(rootViewController: profController)
                self.present(navCotroller, animated: true, completion: nil)
            }
            
            if(currentLevel == "Patient"){
                guard let uid = Auth.auth().currentUser?.uid else{
                    return
                }
                
                ref.child("prescriptions").child(uid).observe(.childAdded, with: { (snapshot) in
                    
                    
                    if let dictionary = snapshot.value as? [String: AnyObject] {
                        
                        let prescription = eachPrescription(dictionary: dictionary)
                        
                        
                        self.scheduleNotification(prescrip: prescription)
                    }
                    
                }, withCancel: nil)
                
                
                ref.child("notifications").child(uid).observe(.childAdded, with: { (snapshot) in
                    
                    
                    if let dictionary = snapshot.value as? [String: AnyObject] {
                        
                        let order = OrderModel(dictionary: dictionary)
                    
                        if(order.notified == "no"){
                        self.scheduleNotificationOrderReady(order: order)
                            Database.database().reference().child("notifications").child(uid).child((order.orderId)!).updateChildValues(["notified":"yes"])
                            
                            Database.database().reference().child("patients").child(uid).child((order.orderId)!).updateChildValues(["notified":"yes"])
                        }
                    }
                    
                }, withCancel: nil)
                
                TouchIDCall()
                

            }
            
            if(currentLevel == "Pharmacist"){
                let profController = PharmaOrdersTableViewController()
                let navCotroller = UINavigationController(rootViewController: profController)
                self.present(navCotroller, animated: true, completion: nil)
            }
            

        }
        
        view.addSubview(inputContainerView)
        view.addSubview(loginButton)
        view.addSubview(registerButton)
        view.addSubview(fingerImage)
        view.addSubview(appimage)
        
        setConstraintsContainerView()
       setConstraintsLoginButton()
        setConstraintsRegisterButton()
        setConstraintsFingerPrintImage()
        setConstraintsImage()
        
        emailTextFiled.delegate = self
        passwordTextFiled.delegate = self
    }
    

    func scheduleNotification(prescrip:eachPrescription){
        let dateAsString = prescrip.time!
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        
        let date = dateFormatter.date(from: dateAsString)
        dateFormatter.dateFormat = "HH:mm"
        
        let Date24 = dateFormatter.string(from: date!)
        print("24 hour formatted Date:",Date24)
        
        let result = Date24.split(separator: ":")

     let center = UNUserNotificationCenter.current()
     let content = UNMutableNotificationContent()
     content.title = "Time for pill"
     content.body = "Please have \((prescrip.pill)!) for your \((prescrip.disease)!)"
     content.categoryIdentifier = "alarm"
     content.userInfo = ["customData": "fizzbuzz"]
     content.sound = UNNotificationSound.default()
     
     var dateComponents = DateComponents()
     dateComponents.hour = Int(result[0])
     dateComponents.minute = Int(result[1])
     // let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: false)
     let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
     let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
     center.add(request)
    }
    
    
    
    func scheduleNotificationOrderReady(order:OrderModel){
        print("notify order")
        let center = UNUserNotificationCenter.current()
        let content = UNMutableNotificationContent()
        content.title = "Time for pickup"
        content.body = "The medicines with orderID \((order.orderId)!) are ready for pickup"
        content.categoryIdentifier = "alarm"
        content.userInfo = ["customData": "fizzbuzz"]
        content.sound = UNNotificationSound.default()
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        center.add(request)
    }
    
    func TouchIDCall(){
        let authContext : LAContext = LAContext()
        var error : NSError?
        
        if authContext.canEvaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            
            authContext.evaluatePolicy(LAPolicy.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Authenticate to log into your Account") { (wasSuccessful, error) in
                if(wasSuccessful){
                    let profController = PatientHomeViewController()
                    let navCotroller = UINavigationController(rootViewController: profController)
                    self.present(navCotroller, animated: true, completion: nil)
                }else{
                    print("No")
                }
            }
        }else{
            let profController = PatientHomeViewController()
            let navCotroller = UINavigationController(rootViewController: profController)
            self.present(navCotroller, animated: true, completion: nil)
        }
    }
    
    @objc func handleSelectFingerPrint(){
        TouchIDCall()
    }
    
    let appimage: UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.image = UIImage(named: "pharmaapp")
        return image
    }()
    
    let fingerImage: UIButton = {
        let image = UIButton()
        image.translatesAutoresizingMaskIntoConstraints = false
         image.setImage(UIImage(named: "fingerprint"), for: .normal)
          image.addTarget(self, action: #selector(handleSelectFingerPrint), for: .touchUpInside)
         image.isUserInteractionEnabled = true
        return image
    }()
    
    
    let inputContainerView: UIView =
    {
        let containerView = UIView()
        containerView.translatesAutoresizingMaskIntoConstraints = false
        containerView.backgroundColor = UIColor.white
        containerView.layer.cornerRadius = 5
        containerView.layer.masksToBounds = true
        return containerView
    }()
    let emailTextFiled: UITextField = {
        let email = UITextField()
        email.translatesAutoresizingMaskIntoConstraints = false
        email.placeholder = "Email"
        email.returnKeyType = UIReturnKeyType.done
        return email
    }()
    
    let passwordTextFiled: UITextField = {
        let password = UITextField()
        password.translatesAutoresizingMaskIntoConstraints = false
        password.placeholder = "Password"
        password.isSecureTextEntry = true
        password.returnKeyType = UIReturnKeyType.done
        return password
    }()
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool
    {
        
        emailTextFiled.resignFirstResponder()
        passwordTextFiled.resignFirstResponder()
        
        return true
    }
    
    let seperatorView: UIView = {
        let line = UIView()
        line.translatesAutoresizingMaskIntoConstraints = false
        line.backgroundColor = UIColor.black
        return line
    }()

    let checkbox1: UIButton = {
        let chckbox = UIButton()
        let image = UIImage(named: "checkboxempty") as UIImage?
        chckbox.translatesAutoresizingMaskIntoConstraints = false
        chckbox.setBackgroundImage(image, for: .normal)
        chckbox.addTarget(self, action: #selector(handleCheckbox1), for: .touchUpInside)
        return chckbox
    }()
    
    @objc func handleCheckbox1(){
        let image1 = UIImage(named: "checkboxchecked") as UIImage?
        let image2 = UIImage(named: "checkboxempty") as UIImage?
        let image3 = UIImage(named: "checkboxempty") as UIImage?
        checkbox1.setBackgroundImage(image1, for: .normal)
        checkbox2.setBackgroundImage(image2, for: .normal)
        checkbox3.setBackgroundImage(image3, for: .normal)
    }
    
    let doctor: UITextField = {
        let doctor = UITextField()
        doctor.translatesAutoresizingMaskIntoConstraints = false
        doctor.text = "Doctor"
        doctor.isUserInteractionEnabled = false
        doctor.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        doctor.textColor = UIColor.white
        return doctor
    }()
    
    let checkbox2: UIButton = {
        let chckbox = UIButton()
        let image = UIImage(named: "checkboxempty") as UIImage?
        chckbox.translatesAutoresizingMaskIntoConstraints = false
        chckbox.setBackgroundImage(image, for: .normal)
        chckbox.addTarget(self, action: #selector(handleCheckbox2), for: .touchUpInside)
        return chckbox
    }()
    
    @objc func handleCheckbox2(){
        let image1 = UIImage(named: "checkboxempty") as UIImage?
        let image2 = UIImage(named: "checkboxchecked") as UIImage?
        let image3 = UIImage(named: "checkboxempty") as UIImage?
        checkbox1.setBackgroundImage(image1, for: .normal)
        checkbox2.setBackgroundImage(image2, for: .normal)
        checkbox3.setBackgroundImage(image3, for: .normal)
    }
    
    let patient: UITextField = {
        let patient = UITextField()
        patient.translatesAutoresizingMaskIntoConstraints = false
        patient.text = "Patient"
        patient.isUserInteractionEnabled = false
        patient.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        patient.textColor = UIColor.white
        return patient
    }()
    
    let checkbox3: UIButton = {
        let chckbox = UIButton()
        let image = UIImage(named: "checkboxempty") as UIImage?
        chckbox.translatesAutoresizingMaskIntoConstraints = false
        chckbox.setBackgroundImage(image, for: .normal)
        chckbox.addTarget(self, action: #selector(handleCheckbox3), for: .touchUpInside)
        return chckbox
    }()
    
    
    @objc func handleCheckbox3(){
        let image1 = UIImage(named: "checkboxempty") as UIImage?
        let image2 = UIImage(named: "checkboxempty") as UIImage?
        let image3 = UIImage(named: "checkboxchecked") as UIImage?
        checkbox1.setBackgroundImage(image1, for: .normal)
        checkbox2.setBackgroundImage(image2, for: .normal)
        checkbox3.setBackgroundImage(image3, for: .normal)
    }
    
    let pharmacist: UITextField = {
        let pharmacist = UITextField()
        pharmacist.translatesAutoresizingMaskIntoConstraints = false
        pharmacist.text = "Pharmacist"
        pharmacist.isUserInteractionEnabled = false
        pharmacist.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 151/255, alpha: 1)
        pharmacist.textColor = UIColor.white
        return pharmacist
    }()
    
    
    let loginButton: UIButton = {
        let login = UIButton()
        login.translatesAutoresizingMaskIntoConstraints = false
        login.setTitle("Login", for: .normal)
        login.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 251/255, alpha: 1)
        login.addTarget(self, action: #selector(handleLogin), for: .touchUpInside)
        return login
    }()
    
    
    @objc func handleLogin(){
        guard let email = emailTextFiled.text, let password = passwordTextFiled.text else {
            print("Form is not valid")
            return
        }
        
        authref.signIn(withEmail: email, password: password) { (user, error) in
            if error != nil{
                print(error as Any)
                return
            }

            let profController = ProfileViewController()
            let navCotroller = UINavigationController(rootViewController: profController)
            self.present(navCotroller, animated: true, completion: nil)
            
            
            let uid = self.authref.currentUser?.uid
            let childref = self.self.ref.child("users").child(uid!)
            
            // Read User information from DB
            childref.observeSingleEvent(of: .value, with: { (snapshot) in
                
                if let dictionary = snapshot.value as? [String: AnyObject] {
                    
                    
                    let user = UserModel(dictionary: dictionary)
                    
                    let preferences = UserDefaults.standard
                    let currentLevel = user.occupation
                    let currentLevelKey = "currentLevel"
                    preferences.set(currentLevel, forKey: currentLevelKey)
                    preferences.synchronize()
                }
                
            }, withCancel: nil)
        }
    }
    
    lazy var registerButton: UIButton = {
        let register = UIButton()
        register.setTitle("Register", for: .normal)
        register.translatesAutoresizingMaskIntoConstraints = false
        register.addTarget(self, action: #selector(handleRegister), for: .touchUpInside)
        register.backgroundColor = UIColor(displayP3Red: 61/255, green: 91/255, blue: 251/255, alpha: 1)
        return register
    }()
    
    
    @objc func handleRegister(){
        let registerViewController = RegisterViewController()
        let navCotroller = UINavigationController(rootViewController: registerViewController)
        self.present(navCotroller, animated: true, completion: nil)
    }

func setConstraintsContainerView(){
    
    inputContainerView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    inputContainerView.centerYAnchor.constraint(equalTo: view.centerYAnchor,constant:-40).isActive = true
    inputContainerView.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -24).isActive = true
    inputContainerView.heightAnchor.constraint(equalToConstant: 140).isActive = true
    
    inputContainerView.addSubview(emailTextFiled)
    inputContainerView.addSubview(seperatorView)
    inputContainerView.addSubview(passwordTextFiled)
    
    
    emailTextFiled.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 12).isActive = true
    emailTextFiled.topAnchor.constraint(equalTo: inputContainerView.topAnchor, constant: 12).isActive = true
    emailTextFiled.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor, constant: -12).isActive = true
    emailTextFiled.heightAnchor.constraint(equalTo: inputContainerView.heightAnchor, multiplier: 1/3).isActive = true
    

    
    seperatorView.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 12).isActive = true
    seperatorView.topAnchor.constraint(equalTo: emailTextFiled.bottomAnchor, constant: 12).isActive = true
    seperatorView.widthAnchor.constraint(equalTo: emailTextFiled.widthAnchor).isActive = true
    seperatorView.heightAnchor.constraint(equalToConstant: 1).isActive = true
    
    
    passwordTextFiled.leftAnchor.constraint(equalTo: inputContainerView.leftAnchor, constant: 12).isActive = true
    passwordTextFiled.topAnchor.constraint(equalTo: seperatorView.topAnchor, constant: 12).isActive = true
    passwordTextFiled.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor, constant: -12).isActive = true
    passwordTextFiled.heightAnchor.constraint(equalTo: inputContainerView.heightAnchor, multiplier: 1/3).isActive = true
    
}
   
    func setConstraintsLoginButton(){
        loginButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        loginButton.topAnchor.constraint(equalTo: inputContainerView.bottomAnchor, constant: 40).isActive = true
        loginButton.widthAnchor.constraint(equalTo: inputContainerView.widthAnchor).isActive = true
        loginButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    func setConstraintsRegisterButton(){
        registerButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        registerButton.topAnchor.constraint(equalTo: loginButton.bottomAnchor, constant: 12).isActive = true
        registerButton.widthAnchor.constraint(equalTo: loginButton.widthAnchor).isActive = true
        registerButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    func setConstraintsFingerPrintImage(){
        fingerImage.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        fingerImage.topAnchor.constraint(equalTo: registerButton.bottomAnchor, constant:20).isActive = true
        fingerImage.widthAnchor.constraint(equalToConstant: 50).isActive = true
        fingerImage.heightAnchor.constraint(equalToConstant: 50).isActive = true
    }
    
    func setConstraintsImage()
    {
        appimage.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        appimage.bottomAnchor.constraint(equalTo: inputContainerView.topAnchor, constant: -20).isActive = true
        appimage.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -70).isActive = true
        appimage.heightAnchor.constraint(equalToConstant: 80).isActive = true
    }

override var preferredStatusBarStyle: UIStatusBarStyle{
    return .lightContent
}



}

