//
//  PageScrollViewController.swift
//  BeWell
//
//  Created by toppy on 5/2/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class PageScrollViewController: UIViewController, UIScrollViewDelegate {
    var contentWidth:CGFloat = 0.0
    var alreadyseen: String?
    
    @IBOutlet var pageControl: UIPageControl!
    
    @IBOutlet var scrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let preferences = UserDefaults.standard
        let currentLevelKey = "alreadyseen"
        if preferences.object(forKey: currentLevelKey) == nil {
            print("doesn't exist")
        } else {
            alreadyseen = preferences.string(forKey: currentLevelKey)
        }
        
        if(alreadyseen == "true"){
            let profController = LoginViewController()
            let navCotroller = UINavigationController(rootViewController: profController)
            self.present(navCotroller, animated: true, completion: nil)
        }
        
           navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Skip", style: .plain, target: self, action: #selector(handleskip))
        navigationItem.rightBarButtonItem?.tintColor = UIColor.white
        
        scrollView.delegate = self
       for image in 0...2 {
            let imagedis = UIImage(named: "\(image).jpg")
            let imageview = UIImageView(image: imagedis)
            let xCoordinate = view.frame.midX + view.frame.width * CGFloat(image)
            let label = UILabel()
        if image == 0 {
            label.text = "A Doctor??\nPrescribe medicines here"
        }
        if image == 1 {
            label.text = "A Patient??\nGet notified here"
        }
        if image == 2 {
            label.text = "A Pharmacist??\nGet orders here"
        }
        label.textColor = UIColor.white
        label.font = label.font.withSize(30)
        label.textAlignment = NSTextAlignment.center
        label.lineBreakMode = .byWordWrapping
        label.numberOfLines = 0

        contentWidth += view.frame.width
        scrollView.addSubview(imageview)
        imageview.frame = CGRect(x: xCoordinate - 125, y: (view.frame.height/2) - 125, width: 250, height: 250)
        scrollView.addSubview(label)
        label.frame = CGRect(x: xCoordinate - 200, y: (view.frame.height/2) - 250, width: 400, height: 150)
        
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: view.frame.height)
    }

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        pageControl.currentPage = Int(scrollView.contentOffset.x /
        CGFloat(414) )
    }
    
    
    @objc func handleskip(){
        
        let preferences = UserDefaults.standard
        let currentLevel = "true"
        let currentLevelKey = "alreadyseen"
        preferences.set(currentLevel, forKey: currentLevelKey)
        preferences.synchronize()
        
        let profController = LoginViewController()
        let navCotroller = UINavigationController(rootViewController: profController)
        self.present(navCotroller, animated: true, completion: nil)
        
    }
    
    

}
