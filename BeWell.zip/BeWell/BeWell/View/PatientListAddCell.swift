//
//  PatientListAddCell.swift
//  BeWell
//
//  Created by toppy on 4/15/18.
//  Copyright © 2018 Adarsh Venkatesh Bodineni. All rights reserved.
//

import UIKit

class PatientListAddCell: UITableViewCell {

    override func layoutSubviews() {
        super.layoutSubviews()
        textLabel?.frame=CGRect(x:70,y:textLabel!.frame.origin.y - 2, width:
            textLabel!.frame.width,height:textLabel!.frame.height)
        detailTextLabel?.frame=CGRect(x:64,y:detailTextLabel!.frame.origin.y + 2 ,width:
            detailTextLabel!.frame.width,height:detailTextLabel!.frame.height)
    }
    
    let iconImageView:UIImageView={
        let imageView=UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints=false
        imageView.layer.cornerRadius=5
        imageView.layer.masksToBounds=true
        imageView.image = UIImage(named: "defimage")
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    var addIcon:UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.image = UIImage(named: "add")
      //  image.isUserInteractionEnabled = true
        image.contentMode = .scaleAspectFill
        return image
        
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
        
        addSubview(iconImageView)
        
        iconImageView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 8).isActive=true
        iconImageView.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive=true
        iconImageView.centerXAnchor.constraint(equalTo: self.centerXAnchor)
        iconImageView.widthAnchor.constraint(equalToConstant: 40).isActive=true
        iconImageView.heightAnchor.constraint(equalToConstant: 40).isActive=true
        
        
        addSubview(addIcon)
        
        addIcon.rightAnchor.constraint(equalTo: self.rightAnchor, constant: -10).isActive = true
        addIcon.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        addIcon.widthAnchor.constraint(equalToConstant: 40).isActive = true
        addIcon.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension UIViewController {
    
    func showToast(message : String) {
        
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.font = UIFont(name: "Montserrat-Light", size: 12.0)
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    } }
